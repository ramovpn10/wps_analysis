<?php
session_start();
$msg = $_SESSION['msg'] ?? '';
unset($_SESSION['msg']);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TXT File Inspector</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;color:#17202a}
.wrap{max-width:1100px;margin:40px auto;padding:0 18px}
.card{background:#fff;border-radius:16px;padding:24px;box-shadow:0 6px 24px rgba(0,0,0,.08);margin-bottom:18px}
h1{margin:0 0 8px}.muted{color:#667085}
.nav{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.nav a{padding:10px 14px;border-radius:10px;background:#eef2f6;color:#17202a;text-decoration:none}
.drop{border:2px dashed #c7cdd4;border-radius:14px;padding:34px;text-align:center}
input[type=file]{margin:15px 0}
button{background:#17202a;color:#fff;border:0;padding:11px 18px;border-radius:10px;cursor:pointer}
.msg{background:#fff8e7;padding:12px;border-radius:10px;margin-bottom:16px}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>فاحص ملفات TXT</h1>
    <div class="muted">قراءة وفحص ومقارنة ملفات TXT الموجودة دون إعادة بناء أو تعديل محتواها.</div>
    <div class="nav">
      <a href="inspect.php">فحص ملف</a>
      <a href="compare.php">مقارنة ملفين</a>
      <a href="download.php">تنزيل النسخة الأصلية</a>
    </div>
  </div>

  <?php if($msg): ?><div class="card msg"><?=htmlspecialchars($msg)?></div><?php endif; ?>

  <div class="card">
    <div class="drop">
      <h2>ارفع ملف TXT للفحص</h2>
      <form method="post" action="upload.php" enctype="multipart/form-data">
        <input type="file" name="txtfile" accept=".txt,text/plain" required><br>
        <button type="submit">رفع وفحص</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
