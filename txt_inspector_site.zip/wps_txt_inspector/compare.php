<?php
session_start();
require __DIR__.'/common.php';
$result = null; $msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $main = raw_data();
    if (!$main) { $msg='ارفع الملف الأول من الصفحة الرئيسية.'; }
    elseif (!isset($_FILES['ref']) || $_FILES['ref']['error']!==UPLOAD_ERR_OK) { $msg='اختر ملف TXT ثاني.'; }
    else {
        $ref = file_get_contents($_FILES['ref']['tmp_name']);
        $n = max(strlen($main), strlen($ref));
        $first = null;
        for($i=0;$i<$n;$i++){ $a=$main[$i]??null; $b=$ref[$i]??null; if($a!==$b){$first=$i;break;}}
        $result = [
            'exact_equal' => $main === $ref,
            'main_bytes' => strlen($main),
            'reference_bytes' => strlen($ref),
            'first_difference_byte' => $first,
            'main_analysis' => analyze($main),
            'reference_analysis' => analyze($ref)
        ];
    }
}
?>
<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>مقارنة الملفات</title>
<style>
body{font-family:Arial;background:#f4f6f8;margin:0}.wrap{max-width:1100px;margin:30px auto;padding:0 18px}
.card{background:#fff;padding:22px;border-radius:14px;margin-bottom:16px;box-shadow:0 5px 20px rgba(0,0,0,.07)}
button{background:#17202a;color:white;border:0;padding:10px 16px;border-radius:9px}pre{white-space:pre-wrap;background:#f8f9fb;padding:12px;border-radius:10px}
</style></head>
<body><div class="wrap">
<div class="card"><a href="index.php">الرئيسية</a> · <a href="inspect.php">الفحص</a> · <a href="download.php">التنزيل</a></div>
<div class="card"><h2>مقارنة حرفية</h2>
<form method="post" enctype="multipart/form-data">
<input type="file" name="ref" accept=".txt,text/plain" required>
<button type="submit">قارن</button>
</form></div>
<?php if($msg): ?><div class="card"><?=htmlspecialchars($msg)?></div><?php endif; ?>
<?php if($result): ?><div class="card"><pre><?=htmlspecialchars(json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?></pre></div><?php endif; ?>
</div></body></html>
