<?php
function raw_data(): string {
    if (empty($_SESSION['data_b64'])) return '';
    $d = base64_decode($_SESSION['data_b64'], true);
    return $d === false ? '' : $d;
}
function exact_lines(string $data): array {
    // Keep bytes as-is for analysis; split only for measurement.
    return preg_split("/\n/", $data);
}
function field_lengths(string $line): array {
    return array_map('strlen', explode("\t", $line));
}
function analyze(string $data): array {
    $lines = exact_lines($data);
    $without_final = $data !== '' && substr($data,-1) === "\n" ? substr($data,0,-1) : $data;
    $rows = explode("\n",$without_final);
    return [
        'bytes' => strlen($data),
        'bom' => str_starts_with($data, "\xEF\xBB\xBF"),
        'ascii_only' => !preg_match('/[^\x00-\x7F]/', $data),
        'crlf' => substr_count($data,"\r\n"),
        'lf' => substr_count($data,"\n"),
        'tabs' => substr_count($data,"\t"),
        'line_count' => count($rows),
        'line_lengths' => array_map('strlen',$rows),
        'first_line_fields' => count($rows) ? field_lengths($rows[0]) : [],
        'separator_positions' => array_keys(array_filter($rows, fn($r)=>$r==='-')),
        'last_line_length' => count($rows) ? strlen(end($rows)) : 0
    ];
}
