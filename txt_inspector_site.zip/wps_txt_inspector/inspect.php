<?php
session_start();
require __DIR__.'/common.php';
$data = raw_data();
$name = $_SESSION['filename'] ?? '—';
$a = $data !== '' ? analyze($data) : null;
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>فحص الملف</title>
<style>
body{font-family:Arial;background:#f4f6f8;margin:0}.wrap{max-width:1100px;margin:30px auto;padding:0 18px}
.card{background:#fff;padding:22px;border-radius:14px;margin-bottom:16px;box-shadow:0 5px 20px rgba(0,0,0,.07)}
pre{white-space:pre-wrap;word-break:break-all;background:#111;color:#f3f3f3;padding:16px;border-radius:10px;overflow:auto}
table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #eee;text-align:right}
a{color:#175cd3}
</style></head>
<body><div class="wrap">
<div class="card"><a href="index.php">الرئيسية</a> · <a href="compare.php">المقارنة</a> · <a href="download.php">تنزيل الأصل</a></div>
<div class="card"><h2>الفحص الحرفي</h2><p>الملف: <?=htmlspecialchars($name)?></p>
<?php if(!$a): ?><p>ارفع ملفًا أولًا.</p>
<?php else: ?>
<table>
<tr><th>البند</th><th>القيمة</th></tr>
<?php foreach($a as $k=>$v): ?>
<tr><td><?=htmlspecialchars($k)?></td><td><pre style="margin:0;background:#f8f9fb;color:#17202a"><?=htmlspecialchars(json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?></pre></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?></div>
<?php if($data): ?><div class="card"><h3>المحتوى كما هو</h3><pre><?=htmlspecialchars($data)?></pre></div><?php endif; ?>
</div></body></html>
