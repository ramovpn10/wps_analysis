<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['txtfile'])) {
    $_SESSION['msg'] = 'لم يتم اختيار ملف.';
    header('Location: index.php'); exit;
}
$f = $_FILES['txtfile'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    $_SESSION['msg'] = 'فشل رفع الملف.';
    header('Location: index.php'); exit;
}
$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if ($ext !== 'txt') {
    $_SESSION['msg'] = 'المسموح فقط TXT.';
    header('Location: index.php'); exit;
}
if ($f['size'] > 10*1024*1024) {
    $_SESSION['msg'] = 'الملف أكبر من الحد المسموح.';
    header('Location: index.php'); exit;
}
$data = file_get_contents($f['tmp_name']);
$_SESSION['filename'] = basename($f['name']);
$_SESSION['data_b64'] = base64_encode($data);
header('Location: inspect.php'); exit;
