<?php
session_start();
if (empty($_SESSION['data_b64'])) { header('Location: index.php'); exit; }
$data = base64_decode($_SESSION['data_b64'], true);
$name = $_SESSION['filename'] ?? 'original.txt';
header('Content-Type: text/plain; charset=us-ascii');
header('Content-Disposition: attachment; filename="' . basename($name) . '"');
header('Content-Length: ' . strlen($data));
echo $data;
exit;
