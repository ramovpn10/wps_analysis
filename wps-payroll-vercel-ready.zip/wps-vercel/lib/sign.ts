import crypto from 'node:crypto';

export function getSigningKey(): string {
  const key = process.env.SIGNING_PRIVATE_KEY;
  if (!key?.trim()) throw new Error('SIGNING_PRIVATE_KEY غير مضبوط على الخادم. لن يتم إنشاء توقيع وهمي.');
  return key.replace(/\\n/g, '\n');
}

export function signBody(body: string): string {
  const signature = crypto.sign('RSA-SHA256', Buffer.from(body, 'utf8'), getSigningKey());
  const base64 = signature.toString('base64');
  if (signature.length !== 256) throw new Error(`حجم التوقيع RSA المتوقع 256 بايت، الناتج ${signature.length}`);
  if (base64.length !== 344) throw new Error(`طول Base64 المتوقع 344، الناتج ${base64.length}`);
  return base64;
}

export function finalizeFile(body: string, signature: string): string {
  return `${body}-\n${signature}`;
}
