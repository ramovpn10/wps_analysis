# WPS Payroll Generator — Vercel / Next.js

هذا المشروع يعيد بناء مولّد ملفات الأجور على Next.js 16 + TypeScript، مع خادم Node.js داخل Route Handlers في Vercel.

## المرجع
- ملفات TXT الحديثة المقبولة هي المرجع النهائي لتنسيق الملف: Header 122، Detail 583، LF، separator، وRSA/Base64 signature format.
- الموقع القديم استُخدم فقط كمرجع خوارزمي لبعض المدخلات (مثل نمط توليد IBAN القديم) وليس كمرجع لتنسيق الملف الحديث.

## أهم نقطة قبل الإنتاج
التوقيع في الملفات الحديثة التي فحصناها لا يمكن إثبات مفتاحه من عينات TXT وحدها. لذلك التطبيق **لا يختلق توقيعًا**. يجب وضع المفتاح الخاص المعتمد حاليًا في `SIGNING_PRIVATE_KEY` على Vercel. التطبيق يستخدم RSA-SHA256 ويوقع الـbody النهائي قبل الفاصل، ثم يضيف `-\n` ثم Base64 بدون سطر إضافي بعده.

## التشغيل
```bash
npm install
npm run dev
```
ثم افتح `http://localhost:3000`.

## Vercel
1. ارفع المشروع إلى GitHub.
2. استورد المشروع في Vercel.
3. أضف `SIGNING_PRIVATE_KEY` كـSensitive Environment Variable.
4. إن رغبت بقاعدة بيانات دائمة، أضف `DATABASE_URL` من Neon.
5. Deploy.

## قاعدة البيانات
بدون `DATABASE_URL` يعمل الموقع ببيانات مرجعية مدمجة (Read-only seed) كي يكون جاهزًا للتجربة.
مع `DATABASE_URL` يستخدم Postgres لتخزين الموظفين/IBANات التي تضيفها من الواجهة.

## ملاحظة سلامة البيانات
الهويات يجب أن تكون بيانات حقيقية صادرة من الجهة النظامية. التطبيق لا يخترع هوية بشرية عند تركها فارغة؛ بل يوقف التوليد ويطلب إدخالها، حتى لا ينتج ملف أجور غير صالح.

### توليد IBAN
يوجد زر توليد IBAN في الواجهة باستخدام خوارزمية الموقع القديم المرفوع. هذه الخوارزمية وُضعت كمرجع فقط، لأن ملفات TXT الحديثة لا تحتوي على الهويات التي تسمح بإثباتها حرفيًا. للاعتماد التشغيلي، استخدم IBAN مرجعيًا/يدويًا عندما يكون معروفًا.

## Exact-acceptance caveat
The new accepted TXT signatures were tested against the public key from the old supplied PHP site and did not verify. This means the new accepted environment is using a different signing key (or a different signing protocol). The project therefore refuses to invent a signature. Set the current authorized `SIGNING_PRIVATE_KEY` before expecting an exact accepted file.
