import { NextResponse } from 'next/server';
import { buildFile, type GeneratePayload } from '../../../lib/file-builder';
import { finalizeFile, signBody } from '../../../lib/sign';
import { validateFinalFile, validateUnsignedBody } from '../../../lib/validator';

export const runtime = 'nodejs';

function toBase64Utf8(value: string): string {
  return Buffer.from(value, 'utf8').toString('base64');
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as GeneratePayload;
    const built = buildFile(payload);
    const beforeSignature = validateUnsignedBody(built.body);
    if (!beforeSignature.ok) {
      return NextResponse.json({ error: 'فشل فحص البنية قبل التوقيع', validation: beforeSignature }, { status: 422 });
    }

    const signature = signBody(built.body);
    const file = finalizeFile(built.body, signature);
    const validation = validateFinalFile(file);
    if (!validation.ok) {
      return NextResponse.json({ error: 'فشل فحص الملف النهائي', validation }, { status: 422 });
    }

    return NextResponse.json({
      file: toBase64Utf8(file),
      filename: `${payload.batchId || 'payroll'}_${payload.batchDate.replace(/-/g, '')}.txt`,
      validation,
      meta: {
        refNo: built.refNo,
        sessionId: built.sessionId,
        transactionIds: built.transactionIds,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'خطأ غير معروف';
    console.error(error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
