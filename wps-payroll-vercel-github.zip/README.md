# WPS Payroll — Vercel

Self-contained Next.js project for the payroll file generator.

## Deploy
1. Create a **private** GitHub repository.
2. Upload all files in this folder, including `private.pem` and `public.pem`.
3. Import the repository into Vercel.
4. Deploy with the standard Next.js settings.

The signing API is server-side and reads `private.pem` from the project root.

## Important
This repository intentionally contains the private signing key because the owner requested a self-contained deployment package. Keep the GitHub repository private.
