export type PayrollEmployee = {
  id: string;
  name: string;
  iban: string;
  suffix: string;
  active: boolean;
  salary: number;
  fees: number;
  identity?: string;
  transactionSuffix?: string;
};

export type CentralEmployee = {
  id: string;
  code: string;
  iban: string;
  suffix: string;
  active: boolean;
};

/**
 * Reference database extracted from the accepted modern files.
 * These are recurring name/IBAN relationships, not a generator.
 */
export const PAYROLL_REFERENCE_EMPLOYEES: PayrollEmployee[] = [
  { id: 'yasin1', name: 'yasin1', iban: 'SA2480000538608016250756', suffix: '0756', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin2', name: 'yasin2', iban: 'SA4280000538608016250723', suffix: '0723', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin3', name: 'yasin3', iban: 'SA6480000538608016250715', suffix: '0715', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin4', name: 'yasin4', iban: 'SA2080000538608016250731', suffix: '0731', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin5', name: 'yasin5', iban: 'SA1180000538608016250699', suffix: '0699', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin6', name: 'yasin6', iban: 'SA3480000538608016250673', suffix: '0673', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin7', name: 'yasin7', iban: 'SA1980000538608016250749', suffix: '0749', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin8', name: 'yasin8', iban: 'SA1280000538608016250681', suffix: '0681', active: true, salary: 402, fees: 1.59 },
  { id: 'yasin9', name: 'yasin9', iban: 'SA8680000538608016250707', suffix: '0707', active: true, salary: 402, fees: 1.59 },
];

export const CENTRAL_REFERENCE_EMPLOYEES: CentralEmployee[] = [
  { id: 'central-i', code: 'i', iban: 'SA8780000135608016257550', suffix: '7550', active: true },
  { id: 'central-H', code: 'H', iban: 'SA8280000135608016257543', suffix: '7543', active: true },
  { id: 'central-G', code: 'G', iban: 'SA0780000135608016257535', suffix: '7535', active: true },
  { id: 'central-F', code: 'F', iban: 'SA2280000135608016256586', suffix: '6586', active: true },
  { id: 'central-D', code: 'D', iban: 'SA5480000135608016256495', suffix: '6495', active: true },
  { id: 'central-C', code: 'C', iban: 'SA7880000135608016256354', suffix: '6354', active: true },
  { id: 'central-E', code: 'E', iban: 'SA9780000135608016256594', suffix: '6594', active: true },
  { id: 'central-A', code: 'A', iban: 'SA6580000135608016256297', suffix: '6297', active: true },
  { id: 'central-B', code: 'B', iban: 'SA4380000135608016256305', suffix: '6305', active: true },
];

export const PAYROLL_TEMPLATES = [
  {
    id: 'payroll-402-159',
    label: 'Payroll 09-111963 — 402 + 1.59',
    salary: 402,
    fees: 1.59,
    clientId: '00074550',
    sourceIban: 'SA9880000538608016250103',
    type: 'P000' as const,
    exampleBatchId: '09-111963',
    exampleRefNo: '2026081520114301',
    exampleSession: '531858',
  },
  {
    id: 'payroll-700-133',
    label: 'Payroll 01-4539384 — 700 + 1.33',
    salary: 700,
    fees: 1.33,
    clientId: '00074550',
    sourceIban: 'SA9880000538608016250103',
    type: 'P000' as const,
    exampleBatchId: '01-4539384',
    exampleRefNo: '2026081704022301',
    exampleSession: '531946',
  },
];

export const CENTRAL_TEMPLATES = [
  {
    id: 'central-09-111963',
    label: 'Centralization 09-111963',
    clientId: '00071344',
    sourceIban: 'SA4280000135608016256420',
    type: 'P000' as const,
    exampleBatchId: '09-111963',
    exampleRefNo: '9-111963 33',
    exampleSession: '531904',
  },
  {
    id: 'central-14-4011836',
    label: 'Centralization 14-4011836',
    clientId: '00071344',
    sourceIban: 'SA4380000135608016256305',
    type: 'P000' as const,
    exampleBatchId: '14-4011836',
    exampleRefNo: '14 - 4011836 5',
    exampleSession: '532012',
  },
];
