import crypto from 'node:crypto';

export function randomDigits(length: number): string {
  const max = 10 ** length;
  const min = 10 ** (length - 1);
  const n = crypto.randomInt(min, max);
  return String(n).padStart(length, '0');
}

export function generateRefNo(now = new Date()): string {
  const yyyy = now.getFullYear().toString().padStart(4, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mi = String(now.getMinutes()).padStart(2, '0');
  const ss = String(now.getSeconds()).padStart(2, '0');
  const ff = String(Math.floor(now.getMilliseconds() / 10)).padStart(2, '0');
  return `${yyyy}${mm}${dd}${hh}${mi}${ss}${ff}`;
}

export function generateSessionId(): string {
  return randomDigits(6);
}

export function generateTransactionSuffix(used: Set<string>): string {
  for (let i = 0; i < 1000; i++) {
    const suffix = randomDigits(4);
    if (!used.has(suffix)) return suffix;
  }
  throw new Error('تعذر إنشاء Transaction Suffix فريد');
}

export function buildTransactionId(dateYYYYMMDD: string, sessionId: string, suffix: string): string {
  const shortDate = dateYYYYMMDD.slice(2, 8);
  if (!/^\d{6}$/.test(sessionId)) throw new Error('Session ID يجب أن يكون 6 أرقام');
  if (!/^\d{4}$/.test(suffix)) throw new Error('Transaction Suffix يجب أن يكون 4 أرقام');
  return `${shortDate}${sessionId}${suffix}`;
}

export function validateIdentity(id: string): boolean {
  return /^\d{10}$/.test(id);
}
