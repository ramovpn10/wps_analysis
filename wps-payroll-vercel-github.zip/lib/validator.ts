import { DETAIL_FIELD_LENGTHS, HEADER_FIELD_LENGTHS } from './format';

export type Validation = {
  ok: boolean;
  errors: string[];
  warnings: string[];
  headerLength?: number;
  detailLengths: number[];
  signatureLength?: number;
};

export function validateUnsignedBody(body: string): Validation {
  const errors: string[] = [];
  const warnings: string[] = [];
  const detailLengths: number[] = [];
  if (!body) return { ok: false, errors: ['المحتوى فارغ'], warnings, detailLengths };
  if (body.includes('\r')) errors.push('الملف يحتوي CR؛ المرجع يستخدم LF فقط');

  const lines = body.split('\n');
  const header = lines[0] ?? '';
  const details = lines.slice(1).filter(Boolean);
  if (header.length !== 122) errors.push(`Header: ${header.length} بدل 122`);
  const headerFields = header.split('\t');
  if (headerFields.length !== HEADER_FIELD_LENGTHS.length) errors.push(`Header fields: ${headerFields.length} بدل 10`);
  headerFields.forEach((f, i) => { if (f.length !== HEADER_FIELD_LENGTHS[i]) errors.push(`Header field ${i + 1}: ${f.length} بدل ${HEADER_FIELD_LENGTHS[i]}`); });

  details.forEach((line, idx) => {
    detailLengths.push(line.length);
    if (line.length !== 583) errors.push(`Detail ${idx + 1}: ${line.length} بدل 583`);
    const fields = line.split('\t');
    if (fields.length !== 14) errors.push(`Detail ${idx + 1}: fields ${fields.length} بدل 14`);
    fields.forEach((f, i) => { if (f.length !== DETAIL_FIELD_LENGTHS[i]) errors.push(`Detail ${idx + 1} field ${i + 1}: ${f.length} بدل ${DETAIL_FIELD_LENGTHS[i]}`); });
  });
  if (details.length !== 9) warnings.push(`عدد التفاصيل الحالي ${details.length}; المرجع التشغيلي لهذه الواجهة 9`);

  return { ok: errors.length === 0, errors, warnings, headerLength: header.length, detailLengths };
}

export function validateFinalFile(file: string): Validation {
  const result = validateUnsignedBody(file.includes('\n-\n') ? file.slice(0, file.indexOf('\n-\n') + 1) : file);
  const marker = '\n-\n';
  const idx = file.indexOf(marker);
  if (idx < 0) {
    result.ok = false;
    result.errors.push('Separator غير موجود');
    return result;
  }
  const signature = file.slice(idx + marker.length);
  result.signatureLength = signature.length;
  if (!signature) {
    result.ok = false;
    result.errors.push('التوقيع غير موجود');
  } else if (signature.length !== 344) {
    result.ok = false;
    result.errors.push(`التوقيع: ${signature.length} بدل 344`);
  }
  if (file.endsWith('\n')) {
    result.ok = false;
    result.errors.push('لا يجب أن يوجد LF بعد التوقيع');
  }
  return result;
}
