export const HEADER_FIELD_LENGTHS = [4, 10, 24, 3, 8, 16, 8, 16, 6, 18] as const;
export const DETAIL_FIELD_LENGTHS = [16, 34, 140, 140, 140, 6, 13, 13, 13, 13, 10, 16, 8, 8] as const;

export function padRight(value: string | number, length: number): string {
  const raw = String(value ?? '');
  if (raw.length > length) throw new Error(`الحقل أطول من الطول المسموح (${length}): ${raw}`);
  return raw.padEnd(length, ' ');
}

export function formatAmount(value: number, length: 13 | 16): string {
  if (!Number.isFinite(value)) throw new Error('المبلغ غير صالح');
  const formatted = value.toFixed(2).replace('.', ',');
  if (formatted.length > length) throw new Error(`المبلغ أكبر من طول الحقل ${length}`);
  return formatted.padStart(length, '0');
}

export function asDateYYYYMMDD(date: string | Date): string {
  if (date instanceof Date) {
    const yyyy = date.getFullYear().toString().padStart(4, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}${mm}${dd}`;
  }
  const clean = String(date).replace(/-/g, '');
  if (!/^\d{8}$/.test(clean)) throw new Error('تاريخ الدفعة يجب أن يكون YYYY-MM-DD');
  return clean;
}

export function totalPayroll(salary: number, fees: number): number {
  return Math.round((salary + fees) * 100) / 100;
}

export function validateIban(iban: string): boolean {
  return /^SA\d{22}$/.test(iban);
}

export function ibanMod97(iban: string): number {
  const normalized = iban.replace(/\s+/g, '').toUpperCase();
  if (!/^SA\d{22}$/.test(normalized)) throw new Error('IBAN غير صحيح');
  const rearranged = normalized.slice(4) + normalized.slice(0, 4);
  let expanded = '';
  for (const ch of rearranged) {
    if (/[A-Z]/.test(ch)) expanded += String(ch.charCodeAt(0) - 55);
    else expanded += ch;
  }
  let remainder = 0;
  for (const digit of expanded) remainder = (remainder * 10 + Number(digit)) % 97;
  return remainder;
}
