import { neon } from '@neondatabase/serverless';
import { PAYROLL_REFERENCE_EMPLOYEES } from './reference';

export type StoredEmployee = {
  id: string;
  name: string;
  iban: string;
  suffix: string;
  kind: 'payroll' | 'centralization';
};

export async function getEmployees(): Promise<StoredEmployee[]> {
  const url = process.env.DATABASE_URL;
  if (!url) return PAYROLL_REFERENCE_EMPLOYEES.map(({ id, name, iban, suffix }) => ({ id, name, iban, suffix, kind: 'payroll' as const }));
  const sql = neon(url);
  await sql`CREATE TABLE IF NOT EXISTS payroll_reference_employees (id text primary key, name text not null, iban text not null, suffix text not null, kind text not null default 'payroll', created_at timestamptz not null default now())`;
  const rows = await sql`SELECT id,name,iban,suffix,kind FROM payroll_reference_employees ORDER BY name`;
  return rows as unknown as StoredEmployee[];
}

export async function upsertEmployee(employee: StoredEmployee): Promise<StoredEmployee> {
  const url = process.env.DATABASE_URL;
  if (!url) return employee;
  const sql = neon(url);
  await sql`CREATE TABLE IF NOT EXISTS payroll_reference_employees (id text primary key, name text not null, iban text not null, suffix text not null, kind text not null default 'payroll', created_at timestamptz not null default now())`;
  await sql`INSERT INTO payroll_reference_employees (id,name,iban,suffix,kind) VALUES (${employee.id},${employee.name},${employee.iban},${employee.suffix},${employee.kind}) ON CONFLICT (id) DO UPDATE SET name=excluded.name, iban=excluded.iban, suffix=excluded.suffix, kind=excluded.kind`;
  return employee;
}
