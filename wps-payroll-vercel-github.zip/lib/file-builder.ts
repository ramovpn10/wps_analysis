import { buildTransactionId } from './identifiers';
import { asDateYYYYMMDD, DETAIL_FIELD_LENGTHS, formatAmount, HEADER_FIELD_LENGTHS, padRight, totalPayroll } from './format';

export type GeneratePayload = {
  mode: 'payroll' | 'centralization';
  unifiedNumber?: string;
  clientId: string;
  sourceIban: string;
  batchDate: string;
  batchId: string;
  refNo?: string;
  sessionId?: string;
  type?: string;
  currency?: string;
  status?: string;
  payrollTemplate?: string;
  workers: Array<{
    identity?: string;
    name: string;
    iban: string;
    salary: number;
    fees: number;
    transactionSuffix?: string;
    centralizationRef?: string;
    code?: string;
  }>;
};

export type BuiltFile = {
  body: string;
  header: string;
  details: string[];
  refNo: string;
  sessionId: string;
  transactionIds: string[];
};

function assertFixedFields(fields: string[], lengths: readonly number[], context: string) {
  if (fields.length !== lengths.length) throw new Error(`${context}: عدد الحقول غير صحيح`);
  fields.forEach((field, i) => {
    if (field.length !== lengths[i]) throw new Error(`${context}: طول الحقل ${i + 1} = ${field.length} بدل ${lengths[i]}`);
  });
}

function buildHeader(p: GeneratePayload, date: string, total: number, refNo: string): string {
  const fields = [
    padRight('RJHI', 4),
    padRight(p.clientId, 10),
    padRight(p.sourceIban, 24),
    padRight(p.currency ?? 'SAR', 3),
    padRight(date, 8),
    formatAmount(total, 16),
    padRight(date, 8),
    padRight(refNo, 16),
    padRight(p.type ?? 'P000', 6),
    padRight(p.batchId, 18),
  ];
  assertFixedFields(fields, HEADER_FIELD_LENGTHS, 'Header');
  const line = fields.join('\t');
  if (line.length !== 122) throw new Error(`Header النهائي ليس 122: ${line.length}`);
  return line;
}

function buildPayrollDetail(
  worker: GeneratePayload['workers'][number],
  date: string,
  sessionId: string,
  suffix: string,
): string {
  const identity = worker.identity?.trim() ?? '';
  if (!/^\d{10}$/.test(identity)) throw new Error(`هوية العامل ${worker.name} يجب أن تكون 10 أرقام`);
  const transactionId = buildTransactionId(date, sessionId, suffix);
  const total = totalPayroll(worker.salary, worker.fees);

  const fields = [
    formatAmount(total, 16),
    padRight(worker.iban.replace(/\s+/g, ''), 34),
    padRight(worker.name, 140),
    padRight('RJHI', 140),
    padRight('Payroll', 140),
    padRight('', 6),
    formatAmount(worker.salary, 13),
    formatAmount(0, 13),
    formatAmount(worker.fees, 13),
    formatAmount(0, 13),
    padRight(identity, 10),
    padRight(transactionId, 16),
    padRight('Success', 8),
    padRight(date, 8),
  ];
  assertFixedFields(fields, DETAIL_FIELD_LENGTHS, `Detail ${worker.name}`);
  const line = fields.join('\t');
  if (line.length !== 583) throw new Error(`Detail ${worker.name}: ${line.length}`);
  return line;
}

function buildCentralDetail(
  worker: GeneratePayload['workers'][number],
  date: string,
  sessionId: string,
  suffix: string,
): string {
  const transactionId = buildTransactionId(date, sessionId, suffix);
  const total = totalPayroll(worker.salary, worker.fees);
  const code = worker.code?.trim() || '';
  const centralRef = worker.centralizationRef?.trim() || '';
  if (!code) throw new Error('Centralization: code مطلوب');
  if (!centralRef) throw new Error('Centralization: Centralization Ref مطلوب');
  const recordIdentity = worker.identity?.trim() ?? '';
  if (!/^\d{10}$/.test(recordIdentity)) throw new Error(`Record ID/identity للعامل ${code} يجب أن يكون 10 أرقام`);

  const fields = [
    formatAmount(total, 16),
    padRight(worker.iban.replace(/\s+/g, ''), 34),
    padRight(code, 140),
    padRight('RJHI', 140),
    padRight(`Centralization Ref:${centralRef}`, 140),
    padRight('', 6),
    formatAmount(total, 13),
    formatAmount(0, 13),
    formatAmount(0, 13),
    formatAmount(0, 13),
    padRight(recordIdentity, 10),
    padRight(transactionId, 16),
    padRight('Success', 8),
    padRight(date, 8),
  ];
  assertFixedFields(fields, DETAIL_FIELD_LENGTHS, `Centralization ${code}`);
  const line = fields.join('\t');
  if (line.length !== 583) throw new Error(`Centralization ${code}: ${line.length}`);
  return line;
}

export function buildFile(p: GeneratePayload): BuiltFile {
  if (!p.clientId) throw new Error('Client ID مطلوب');
  if (!p.sourceIban) throw new Error('IBAN المصدر مطلوب');
  if (!p.batchId) throw new Error('رقم الدفعة مطلوب');
  if (!p.workers.length) throw new Error('أضف عمالًا قبل التوليد');
  if (p.workers.length !== 9) throw new Error('النسخة المرجعية الحالية مصممة لعدد 9 عمال');

  const date = asDateYYYYMMDD(p.batchDate);
  const refNo = p.refNo?.trim() || '';
  if (!refNo || refNo.length > 16) throw new Error('RefNo يجب إدخاله أو توليده بطول لا يتجاوز 16');
  const sessionId = p.sessionId?.trim() || '';
  if (!/^\d{6}$/.test(sessionId)) throw new Error('Session ID يجب أن يكون 6 أرقام');

  const total = p.workers.reduce((s, w) => s + totalPayroll(w.salary, w.fees), 0);
  const header = buildHeader(p, date, total, refNo);
  const used = new Set<string>();
  const transactionIds: string[] = [];
  const details = p.workers.map((worker) => {
    const suffix = worker.transactionSuffix?.trim() || '';
    if (!/^\d{4}$/.test(suffix)) throw new Error(`Transaction Suffix مفقود للعامل ${worker.name}`);
    if (used.has(suffix)) throw new Error(`Transaction Suffix مكرر: ${suffix}`);
    used.add(suffix);
    const tx = buildTransactionId(date, sessionId, suffix);
    transactionIds.push(tx);
    return p.mode === 'payroll'
      ? buildPayrollDetail(worker, date, sessionId, suffix)
      : buildCentralDetail(worker, date, sessionId, suffix);
  });

  const body = `${header}\n${details.join('\n')}\n`;
  return { body, header, details, refNo, sessionId, transactionIds };
}
