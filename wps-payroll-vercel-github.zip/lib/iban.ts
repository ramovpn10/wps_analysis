/**
 * Legacy reference algorithm recovered from the supplied older working site.
 * It is retained as an optional generator; accepted modern files are the final
 * authority, so users can override it with an exact reference/database IBAN.
 */
export async function generateLegacyIban(id: string, unifiedNumber: string, companyIban: string): Promise<string> {
  const cleanCompanyIban = companyIban.trim().replace(/\s+/g, '');
  if (!/^SA\d{22}$/.test(cleanCompanyIban)) throw new Error('IBAN المصدر غير صحيح');
  const middlePart = cleanCompanyIban.substring(4, 20);
  const source = `${unifiedNumber.trim()}|${id.trim()}`;
  const data = new TextEncoder().encode(source);
  const hash = await crypto.subtle.digest('SHA-256', data);
  const digits = Array.from(new Uint8Array(hash)).map((x) => x % 10).join('');
  const checkDigits = digits.substring(0, 2);
  const variableSuffix = digits.substring(2, 6);
  return `SA${checkDigits}${middlePart}${variableSuffix}`;
}
