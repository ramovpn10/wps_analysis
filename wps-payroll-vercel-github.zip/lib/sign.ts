import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

/**
 * Signing method kept compatible with the old PHP signer:
 *
 * openssl_sign($fileContent, $signature, $privateKey, OPENSSL_ALGO_SHA256)
 *
 * Node's RSA-SHA256 with explicit PKCS#1 v1.5 padding produces the same
 * signature scheme as OpenSSL's default RSA signature mode used by
 * openssl_sign(). The exact UTF-8 bytes of the unsigned file body are signed.
 */
export function getSigningKey(): string {
  const envKey = process.env.SIGNING_PRIVATE_KEY;
  if (envKey?.trim()) return envKey.replace(/\\n/g, '\n');

  const localPath = path.join(process.cwd(), 'secrets', 'private.pem');
  if (fs.existsSync(localPath)) {
    return fs.readFileSync(localPath, 'utf8');
  }

  throw new Error('لم يتم العثور على مفتاح التوقيع. اضبط SIGNING_PRIVATE_KEY على Vercel أو ضع secrets/private.pem في بيئة التشغيل المحلية.');
}


export function getPublicKey(): string {
  const envKey = process.env.SIGNING_PUBLIC_KEY;
  if (envKey?.trim()) return envKey.replace(/\\n/g, '\n');

  const localPath = path.join(process.cwd(), 'secrets', 'public.pem');
  if (fs.existsSync(localPath)) return fs.readFileSync(localPath, 'utf8');

  throw new Error('لم يتم العثور على المفتاح العام للتحقق. اضبط SIGNING_PUBLIC_KEY على Vercel أو ضع secrets/public.pem محليًا.');
}

export function signBody(body: string): string {
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(Buffer.from(body, 'utf8'));
  signer.end();

  const signature = signer.sign({
    key: getSigningKey(),
    padding: crypto.constants.RSA_PKCS1_PADDING,
  });

  const base64 = signature.toString('base64');

  if (signature.length !== 256) {
    throw new Error(`حجم التوقيع RSA المتوقع 256 بايت، الناتج ${signature.length}`);
  }
  if (base64.length !== 344) {
    throw new Error(`طول Base64 المتوقع 344، الناتج ${base64.length}`);
  }
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) {
    throw new Error('التوقيع الناتج ليس Base64 صالحًا');
  }

  return base64;
}

export function verifySignature(body: string, signatureBase64: string, publicKey: string): boolean {
  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(Buffer.from(body, 'utf8'));
  verifier.end();
  return verifier.verify(
    { key: publicKey, padding: crypto.constants.RSA_PKCS1_PADDING },
    Buffer.from(signatureBase64, 'base64'),
  );
}

/**
 * New accepted files use LF-only line endings, so we preserve that exact
 * convention.
 */
export function finalizeFile(body: string, signature: string): string {
  const normalized = body.replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n+$/, '');
  return `${normalized}\n-\n${signature}`;
}
