# Reference audit of the 10 accepted files

The uploaded accepted TXT files were checked byte-level before the project was built.

Common invariants across all 10 files:
- Header length: 122 bytes
- Header fields: 10
- Header tabs: 9
- Detail length: 583 bytes
- Detail fields: 14
- Detail tabs: 13
- CRLF occurrences: 0
- Separator: `\n-\n`
- Signature characters: 344 Base64
- No LF after the final signature

Accepted file detail counts vary by file (1, 2, 3, 4, 9, ...), so the UI's 9-worker payroll mode is a reference-template choice, not a claim that every accepted file must contain 9 details.

Payroll references used in the UI:
- 09-111963: 9 records, 402.00 basic + 1.59 fees, 403.59 total per worker.
- 01-4539384: 9 records, 700.00 basic + 1.33 fees, 701.33 total per worker.

Important signing finding:
- The RSA private/public key bundled with the older supplied site does NOT verify the signatures of the new accepted TXT files when tested against the body immediately before the separator. Therefore the old key is not silently reused for the new signer. `SIGNING_PRIVATE_KEY` must contain the currently authorized signing key for the accepted-file system.
