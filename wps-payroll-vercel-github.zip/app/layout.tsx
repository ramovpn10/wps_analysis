import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'مولد ملفات الأجور',
  description: 'مولد ملفات الأجور المرجعية',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
