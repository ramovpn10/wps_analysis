import { NextResponse } from 'next/server';
import { CENTRAL_TEMPLATES, PAYROLL_TEMPLATES } from '../../../lib/reference';

export const runtime = 'nodejs';

export async function GET() {
  return NextResponse.json({ templates: PAYROLL_TEMPLATES, centralTemplates: CENTRAL_TEMPLATES });
}
