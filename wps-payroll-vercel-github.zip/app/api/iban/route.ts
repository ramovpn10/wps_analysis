import { NextResponse } from 'next/server';
import { generateLegacyIban } from '../../../lib/iban';
import { ibanMod97 } from '../../../lib/format';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const body = await request.json() as { identity?: string; unifiedNumber?: string; companyIban?: string };
    if (!/^\d{10}$/.test(body.identity || '')) return NextResponse.json({ error: 'الهوية يجب أن تكون 10 أرقام' }, { status: 400 });
    if (!body.unifiedNumber?.trim()) return NextResponse.json({ error: 'الرقم الموحد مطلوب لتوليد IBAN' }, { status: 400 });
    const iban = await generateLegacyIban(body.identity, body.unifiedNumber, body.companyIban || '');
    const checksum = ibanMod97(iban);
    return NextResponse.json({ iban, mod97: checksum, legacyReference: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'تعذر توليد IBAN' }, { status: 400 });
  }
}
