import { NextResponse } from 'next/server';
import { getEmployees, upsertEmployee, type StoredEmployee } from '../../../lib/db';

export const runtime = 'nodejs';

export async function GET() {
  try {
    const items = await getEmployees();
    return NextResponse.json({ items });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'تعذر تحميل قاعدة البيانات المرجعية' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Partial<StoredEmployee>;
    if (!body.id || !body.name || !body.iban || !body.suffix) {
      return NextResponse.json({ error: 'id/name/iban/suffix مطلوبة' }, { status: 400 });
    }
    const item = await upsertEmployee({
      id: body.id,
      name: body.name,
      iban: body.iban,
      suffix: body.suffix,
      kind: body.kind === 'centralization' ? 'centralization' : 'payroll',
    });
    return NextResponse.json({ item });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'تعذر حفظ السجل المرجعي' }, { status: 500 });
  }
}
