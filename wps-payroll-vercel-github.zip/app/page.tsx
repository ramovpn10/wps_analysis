'use client';

import { useEffect, useMemo, useState } from 'react';

type Employee = {
  id: string;
  name: string;
  iban: string;
  suffix: string;
  identity: string;
  salary: number;
  fees: number;
  transactionSuffix: string;
};

type RefEmployee = { id: string; name: string; iban: string; suffix: string; kind: 'payroll' | 'centralization' };
type Template = { id: string; label: string; salary: number; fees: number; clientId: string; sourceIban: string; exampleBatchId: string; exampleRefNo: string; exampleSession: string };

const seed = [
  ['yasin1','SA2480000538608016250756','0756'],['yasin2','SA4280000538608016250723','0723'],['yasin3','SA6480000538608016250715','0715'],
  ['yasin4','SA2080000538608016250731','0731'],['yasin5','SA1180000538608016250699','0699'],['yasin6','SA3480000538608016250673','0673'],
  ['yasin7','SA1980000538608016250749','0749'],['yasin8','SA1280000538608016250681','0681'],['yasin9','SA8680000538608016250707','0707'],
];
const blank = (): Employee => ({id: crypto.randomUUID(), name:'', iban:'', suffix:'', identity:'', salary:402, fees:1.59, transactionSuffix:''});

export default function Home() {
  const [clientId, setClientId] = useState('00074550');
  const [sourceIban, setSourceIban] = useState('SA9880000538608016250103');
  const [unifiedNumber, setUnifiedNumber] = useState('');
  const [batchDate, setBatchDate] = useState(new Date().toISOString().slice(0,10));
  const [batchId, setBatchId] = useState('09-111963');
  const [refNo, setRefNo] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [mode, setMode] = useState<'payroll'|'centralization'>('payroll');
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState('payroll-402-159');
  const [refs, setRefs] = useState<RefEmployee[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedRefIds, setSelectedRefIds] = useState<string[]>([]);
  const [status, setStatus] = useState<string>('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const total = useMemo(() => employees.reduce((s,e)=>s+Number(e.salary||0)+Number(e.fees||0),0), [employees]);

  useEffect(()=>{
    setEmployees(seed.map(([name,iban,suffix])=>({id:crypto.randomUUID(),name,iban,suffix,identity:'',salary:402,fees:1.59,transactionSuffix:''})));
    fetch('/api/employees').then(r=>r.json()).then(data=>setRefs(data.items||[])).catch(()=>{});
    fetch('/api/templates').then(r=>r.json()).then(data=>setTemplates(data.templates||[])).catch(()=>{
      setTemplates([{id:'payroll-402-159',label:'Payroll 09-111963 — 402 + 1.59',salary:402,fees:1.59,clientId:'00074550',sourceIban:'SA9880000538608016250103',exampleBatchId:'09-111963',exampleRefNo:'2026081520114301',exampleSession:'531858'},{id:'payroll-700-133',label:'Payroll 01-4539384 — 700 + 1.33',salary:700,fees:1.33,clientId:'00074550',sourceIban:'SA9880000538608016250103',exampleBatchId:'01-4539384',exampleRefNo:'2026081704022301',exampleSession:'531946'}]);
    });
  },[]);

  function update(i:number, patch:Partial<Employee>){
    setEmployees(prev=>prev.map((e,idx)=>idx===i?{...e,...patch}:e));
  }
  function applyTemplate(id:string){
    const t=templates.find(x=>x.id===id); if(!t) return;
    setClientId(t.clientId); setSourceIban(t.sourceIban); setBatchId(t.exampleBatchId); setRefNo(t.exampleRefNo); setSessionId(t.exampleSession);
    setEmployees(prev=>prev.map(e=>({...e,salary:t.salary,fees:t.fees})));
  }
  function clearAll(){ setEmployees(prev=>prev.map(e=>({...e,identity:'',transactionSuffix:''}))); setStatus('تم مسح الهويات والمعرفات المتغيرة فقط.'); }
  function fillSelected(){
    const picked=refs.filter(r=>selectedRefIds.includes(r.id));
    if(!picked.length){setStatus('اختر موظفًا واحدًا على الأقل من قاعدة البيانات.');return;}
    setEmployees(prev=>prev.map((e,i)=>{
      const p=picked[i]; return p?{...e,name:p.name,iban:p.iban,suffix:p.suffix}:e;
    }));
    setStatus(`تمت تعبئة ${Math.min(picked.length,9)} عمال من قاعدة البيانات.`);
  }
  async function generate(){
    setLoading(true);setStatus('جارٍ فحص وبناء الملف...');setDownloadUrl('');
    try{
      const cleanRef=refNo || `${batchDate.replaceAll('-','')}${new Date().toTimeString().slice(0,8).replaceAll(':','')}${String(Math.floor(new Date().getMilliseconds()/10)).padStart(2,'0')}`;
      const cleanSession=sessionId || String(Math.floor(100000+Math.random()*900000));
      const workers=employees.map(e=>({identity:e.identity.trim(),name:e.name.trim(),iban:e.iban.trim(),salary:Number(e.salary),fees:Number(e.fees),transactionSuffix:e.transactionSuffix.trim()}));
      const res=await fetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,unifiedNumber,clientId,sourceIban,batchDate,batchId,refNo:cleanRef,sessionId:cleanSession,type:'P000',currency:'SAR',workers})});
      const data=await res.json();
      if(!res.ok) throw new Error(data.error||'تعذر توليد الملف');
      if(data.file){const blob=Uint8Array.from(atob(data.file),c=>c.charCodeAt(0));const url=URL.createObjectURL(new Blob([blob],{type:'text/plain'}));setDownloadUrl(url);}
      setStatus(`تم إنشاء الملف. Header ${data.validation.headerLength}، كل Detail ${data.validation.detailLengths.join(', ')}، توقيع ${data.validation.signatureLength}.`);
    }catch(e:any){setStatus(e?.message||'حدث خطأ');}
    finally{setLoading(false);}
  }

  return <main className="shell">
    <header className="topbar"><div><div className="brand">مدد • مولد الأجور</div><div className="muted">مرجع تنسيق الملفات الحديثة المقبولة</div></div><div className="pill">Vercel / Next.js</div></header>
    <section className="hero"><div><h1>توليد ملف الأجور بدقة مرجعية</h1><p>كل الحقول تُبنى بقيود ثابتة: Header 122، Detail 583، LF فقط، وRSA Base64 في الخادم.</p></div><div className="hero-actions"><button className="btn ghost" onClick={clearAll}>مسح المتغيرات</button><button className="btn primary" onClick={generate} disabled={loading}>{loading?'جارٍ التوليد…':'فحص وتوليد الملف'}</button>{downloadUrl&&<a className="btn success" href={downloadUrl} download={`${batchId || 'payroll'}_${batchDate.replaceAll('-','')}.txt`}>تحميل TXT</a>}</div></section>

    <section className="grid two">
      <div className="card"><div className="card-head"><div><h2>بيانات الدفعة</h2><p>القيم التي تظهر في الـHeader.</p></div></div>
        <div className="fields">
          <label>نوع الملف<select value={mode} onChange={e=>setMode(e.target.value as 'payroll'|'centralization')}><option value="payroll">Payroll</option><option value="centralization">Centralization</option></select></label>
          <label>الرقم الموحد<input value={unifiedNumber} onChange={e=>setUnifiedNumber(e.target.value)} placeholder="اختياري لخوارزمية IBAN القديمة"/></label>
          <label>Client ID<input value={clientId} onChange={e=>setClientId(e.target.value)} maxLength={10}/></label>
          <label>IBAN المصدر<input value={sourceIban} onChange={e=>setSourceIban(e.target.value)} maxLength={24}/></label>
          <label>تاريخ الدفعة<input type="date" value={batchDate} onChange={e=>setBatchDate(e.target.value)}/></label>
          <label>رقم الدفعة<input value={batchId} onChange={e=>setBatchId(e.target.value)} maxLength={18}/></label>
          <label>RefNo<input value={refNo} onChange={e=>setRefNo(e.target.value)} maxLength={16}/></label>
          <label>Session ID<input value={sessionId} onChange={e=>setSessionId(e.target.value)} maxLength={6} inputMode="numeric"/></label>
          <label>قالب راتب مرجعي<select value={selectedTemplate} onChange={e=>{setSelectedTemplate(e.target.value);applyTemplate(e.target.value)}}>{templates.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}</select></label>
        </div>
      </div>
      <div className="card"><div className="card-head"><div><h2>قاعدة البيانات</h2><p>الاسم + IBAN + اللاحقة فقط كبيانات مرجعية ثابتة.</p></div><div className="count">{refs.length}</div></div>
        <div className="db-list">{refs.map(r=><label key={r.id} className="db-row"><input type="checkbox" checked={selectedRefIds.includes(r.id)} onChange={e=>setSelectedRefIds(p=>e.target.checked?[...p,r.id]:p.filter(x=>x!==r.id))}/><span><strong>{r.name}</strong><small>{r.iban}</small></span></label>)}</div>
        <button className="btn secondary full" onClick={fillSelected}>تعبئة العمال المحددين</button>
        <div className="db-actions">
          <button className="btn ghost full" onClick={()=>{setSelectedRefIds(refs.slice(0,9).map(r=>r.id));setTimeout(fillSelected,0);}}>تعبئة أول 9 تلقائيًا</button>
          <label className="import-btn">استيراد IBANات CSV<input type="file" accept=".csv,.txt" onChange={async ev=>{const f=ev.target.files?.[0];if(!f)return;const text=await f.text();const rows=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);let added=0;for(let i=0;i<rows.length;i++){const [name,iban]=rows[i].split(',').map(x=>x?.trim());if(!iban)continue;const item={id:`import-${Date.now()}-${i}`,name:name||`Imported ${i+1}`,iban:iban.replace(/\s/g,''),suffix:iban.replace(/\s/g,'').slice(-4),kind:'payroll'};const r=await fetch('/api/employees',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(item)});if(r.ok){const d=await r.json();setRefs(prev=>[...prev,d.item]);added++;}}setStatus(`تم استيراد ${added} IBAN.`);}}/></label>
        </div>
      </div>
    </section>

    <section className="card workers"><div className="card-head"><div><h2>العمال — 9 سجلات</h2><p>الترتيب الحالي يطابق ترتيب المرجع Payroll عند تعبئته من القالب.</p></div><div className="total">الإجمالي: <b>{total.toFixed(2)}</b> SAR</div></div>
      <div className="worker-grid">{employees.map((e,i)=><article className="worker" key={e.id}><div className="worker-title"><span>{i+1}</span><strong>{e.name||`العامل ${i+1}`}</strong></div>
        <div className="fields compact">
          <label>الهوية<input value={e.identity} onChange={ev=>update(i,{identity:ev.target.value.replace(/\D/g,'').slice(0,10)})} maxLength={10} inputMode="numeric" placeholder="10 أرقام"/></label>
          <label>الاسم<input value={e.name} onChange={ev=>update(i,{name:ev.target.value})}/></label>
          <label>IBAN<input value={e.iban} onChange={ev=>update(i,{iban:ev.target.value.toUpperCase().replace(/\s/g,'')})} maxLength={24}/></label>
          <label>الراتب<input type="number" value={e.salary} onChange={ev=>update(i,{salary:Number(ev.target.value)})} step="0.01"/></label>
          <label>الرسوم<input type="number" value={e.fees} onChange={ev=>update(i,{fees:Number(ev.target.value)})} step="0.01"/></label>
          <label>الإجمالي<input value={(e.salary+e.fees).toFixed(2)} readOnly/></label>
          <label>Transaction Suffix<input value={e.transactionSuffix} onChange={ev=>update(i,{transactionSuffix:ev.target.value.replace(/\D/g,'').slice(0,4)})} maxLength={4} inputMode="numeric" placeholder="4 أرقام"/></label>
        </div>
        <div className="worker-actions">
          <button className="btn secondary" onClick={async()=>{if(!e.identity||!unifiedNumber){setStatus('أدخل الهوية والرقم الموحد أولاً لتوليد IBAN.');return;} const r=await fetch('/api/iban',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identity:e.identity,unifiedNumber,companyIban:sourceIban})}); const d=await r.json(); if(!r.ok){setStatus(d.error||'تعذر توليد IBAN');return;} update(i,{iban:d.iban,suffix:d.iban.slice(-4)}); setStatus(`تم توليد IBAN للعامل ${i+1}.`);}}>توليد IBAN</button>
        </div>
      </article>)}</div>
    </section>

    <section className="card diagnostics"><div className="card-head"><div><h2>حالة التحقق</h2><p>التطبيق يمنع إنشاء ملف ناقص أو بتوقيع وهمي.</p></div></div><div className="status">{status || 'جاهز. أدخل البيانات ثم اضغط فحص وتوليد الملف.'}</div><div className="checks"><span>Header 122</span><span>Detail 583</span><span>LF فقط</span><span>14 حقل</span><span>RSA 2048 / Base64</span></div></section>

    <footer>المرجع النهائي للتنسيق هو الملفات المقبولة الحديثة. الموقع القديم يُستخدم كمرجع خوارزمي فقط عندما تكون العلاقة مثبتة.</footer>
  </main>;
}
