import fs from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
if (!args[0]) {
  console.error('Usage: node scripts/check-structure.mjs <file.txt>');
  process.exit(1);
}
const p = path.resolve(args[0]);
const b = fs.readFileSync(p);
const marker = Buffer.from('\n-\n');
const idx = b.indexOf(marker);
if (idx < 0) throw new Error('Separator not found');
const body = b.subarray(0, idx + 1).toString('utf8');
const lines = body.split('\n').filter(Boolean);
const header = lines[0];
const details = lines.slice(1);
console.log({headerLength: header.length, headerTabs: (header.match(/\t/g)||[]).length, detailCount: details.length, detailLengths: [...new Set(details.map(x=>x.length))], hasCR: b.includes(13), totalBytes: b.length});
