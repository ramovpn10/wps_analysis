import fs from 'node:fs';
import crypto from 'node:crypto';

const keyPath = process.argv[2];
const bodyPath = process.argv[3];
if (!keyPath || !bodyPath) {
  console.error('Usage: node scripts/test-signing.mjs <private.pem> <unsigned-body.txt>');
  process.exit(2);
}
const privateKey = fs.readFileSync(keyPath, 'utf8');
const publicKey = crypto.createPublicKey(privateKey);
const body = fs.readFileSync(bodyPath);

const signer = crypto.createSign('RSA-SHA256');
signer.update(body);
signer.end();
const signature = signer.sign({ key: privateKey, padding: crypto.constants.RSA_PKCS1_PADDING });
const b64 = signature.toString('base64');

const verifier = crypto.createVerify('RSA-SHA256');
verifier.update(body);
verifier.end();
const valid = verifier.verify({ key: publicKey, padding: crypto.constants.RSA_PKCS1_PADDING }, signature);

console.log(JSON.stringify({
  algorithm: 'RSA-SHA256',
  padding: 'RSA_PKCS1_PADDING',
  signatureBytes: signature.length,
  base64Length: b64.length,
  base64Suffix: b64.slice(-2),
  verifies: valid,
}, null, 2));
