import fs from 'node:fs';
import path from 'node:path';

const files = process.argv.slice(2);
if (!files.length) throw new Error('Pass accepted TXT files');

for (const name of files) {
  const b = fs.readFileSync(name);
  const crlf = (b.toString('binary').match(/\r\n/g) || []).length;
  const lf = (b.toString('binary').match(/\n/g) || []).length;
  const marker = Buffer.from('\n-\n');
  const idx = b.indexOf(marker);
  if (idx < 0) throw new Error(`${name}: separator not found`);
  const signature = b.subarray(idx + marker.length);
  const body = b.subarray(0, idx + 1).toString('utf8');
  const lines = body.split('\n').filter(Boolean);
  const header = lines[0];
  const details = lines.slice(1);
  const report = {
    file: path.basename(name), bytes: b.length, headerLength: header.length,
    headerFields: header.split('\t').length, headerTabs: (header.match(/\t/g)||[]).length,
    detailCount: details.length, detailLengths: [...new Set(details.map(x=>x.length))],
    detailFieldCount: details.length ? details[0].split('\t').length : 0,
    detailTabs: details.length ? (details[0].match(/\t/g)||[]).length : 0,
    lf, crlf, endsWithLF: b[b.length-1]===10, signatureChars: signature.toString('utf8').trim().length,
  };
  console.log(JSON.stringify(report));
}
