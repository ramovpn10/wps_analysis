<?php
session_start(); require __DIR__.'/common.php';
$data=raw_data(); $name=$_SESSION['filename']??'—'; $a=$data?inspect_data($data):null;
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>الفحص</title><style>
body{margin:0;background:#f3f5f7;font-family:Arial}.wrap{max-width:1180px;margin:30px auto;padding:0 18px}.bar,.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:18px;margin-bottom:16px}.bar a{margin-left:14px;color:#344054;text-decoration:none}
table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #eaecf0;text-align:right}pre{background:#101828;color:#f9fafb;padding:15px;border-radius:12px;overflow:auto;white-space:pre-wrap;word-break:break-word}
.bad{color:#b42318}.ok{color:#027a48}
</style></head><body><div class="wrap">
<div class="bar"><a href="index.php">الرئيسية</a><a href="compare.php">المقارنة</a><a href="patterns.php">الأنماط</a><a href="sandbox.php">المختبر</a></div>
<div class="card"><h2>فحص حرفي</h2><p><?=h($name)?></p>
<?php if(!$a): ?><p>ارفع ملفاً أولاً.</p><?php else: ?>
<table><tr><th>العنصر</th><th>القيمة</th></tr>
<?php foreach(['bytes','bom','ascii_only','crlf','lf','tabs','rows','header_bytes','header_fields','separator','last_line_bytes'] as $k): ?>
<tr><td><?=h($k)?></td><td><?=h(json_encode($a[$k],JSON_UNESCAPED_UNICODE))?></td></tr>
<?php endforeach; ?></table>
<?php endif; ?></div>
<?php if($a): ?><div class="card"><h3>تفاصيل أسطر البيانات</h3><pre><?=h(json_encode($a['details'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?></pre></div><?php endif; ?>
<?php if($data): ?><div class="card"><h3>المحتوى الخام كما هو</h3><pre><?=h($data)?></pre></div><?php endif; ?>
</div></body></html>
