<?php
session_start();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $seed1=trim($_POST['s1']??'TEST-001');$seed2=trim($_POST['s2']??'TEST-002');$seed3=trim($_POST['s3']??'TEST-003');
 $date=preg_match('/^\d{8}$/',$_POST['date']??'')?$_POST['date']:date('Ymd');
 $tokens=['A','B','C','D','E','F','G','H','I'];
 $rows=[];
 foreach($tokens as $i=>$t){
   $rows[] = [
     'code'=>$t,
     'synthetic_account'=>'TEST-ACCOUNT-'.str_pad((string)($i+1),2,'0',STR_PAD_LEFT),
     'synthetic_id'=>'TEST-ID-'.str_pad((string)($i+1),4,'0',STR_PAD_LEFT),
     'serial'=>substr($date,2).'5319'.str_pad((string)(45683+$i),6,'0',STR_PAD_LEFT)
   ];
 }
 $_SESSION['lab']=json_encode(['seeds'=>[$seed1,$seed2,$seed3],'date'=>$date,'rows'=>$rows],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
 $ok='تم إنشاء نموذج تجريبي مستقل عن أي ملف بنكي.';
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>المختبر</title><style>
body{margin:0;background:#f3f5f7;font-family:Arial}.wrap{max-width:980px;margin:30px auto;padding:0 18px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:18px;margin-bottom:16px}
input{padding:9px;margin:5px;width:90%}button{background:#101828;color:#fff;border:0;padding:11px 16px;border-radius:10px}pre{background:#101828;color:#f9fafb;padding:15px;border-radius:12px;overflow:auto}
</style></head><body><div class="wrap">
<div class="card"><a href="index.php">الرئيسية</a> · <a href="inspect.php">الفحص</a></div>
<div class="card"><h2>المختبر التجريبي</h2>
<p>يختبر العلاقات التي اكتشفناها في المقارنة باستخدام بيانات صناعية فقط.</p>
<form method="post">
<input name="s1" value="TEST-001"><input name="s2" value="TEST-002"><input name="s3" value="TEST-003"><br>
<input name="date" value="<?=htmlspecialchars(date('Ymd'))?>" pattern="\d{8}"><br>
<button>تشغيل التجربة</button>
</form>
<?php if(isset($ok)): ?><p><?=htmlspecialchars($ok)?></p><pre><?=htmlspecialchars($_SESSION['lab'])?></pre><?php endif; ?>
</div></div></body></html>
