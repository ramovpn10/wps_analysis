<?php
session_start(); require __DIR__.'/common.php';
$a=raw_data(); $res=null;
if($_SERVER['REQUEST_METHOD']==='POST' && $a && isset($_FILES['other']) && $_FILES['other']['error']===UPLOAD_ERR_OK){
$b=file_get_contents($_FILES['other']['tmp_name']);
$n=max(strlen($a),strlen($b));$first=null;
for($i=0;$i<$n;$i++){if(($a[$i]??null)!==($b[$i]??null)){ $first=$i;break;}}
$res=['exact'=>$a===$b,'a_bytes'=>strlen($a),'b_bytes'=>strlen($b),'first_difference'=>$first,
'a'=>inspect_data($a),'b'=>inspect_data($b)];
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>مقارنة</title><style>
body{margin:0;background:#f3f5f7;font-family:Arial}.wrap{max-width:1180px;margin:30px auto;padding:0 18px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:18px;margin-bottom:16px}pre{background:#101828;color:#f9fafb;padding:15px;border-radius:12px;overflow:auto}
button{background:#101828;color:#fff;border:0;padding:11px 16px;border-radius:10px}
</style></head><body><div class="wrap"><div class="card"><a href="index.php">الرئيسية</a></div>
<div class="card"><h2>مقارنة حرفية</h2>
<?php if(!$a): ?><p>ارفع ملفاً أولاً من الصفحة الرئيسية.</p><?php else: ?>
<form method="post" enctype="multipart/form-data"><input type="file" name="other" accept=".txt" required> <button>قارن</button></form>
<?php endif; ?></div>
<?php if($res): ?><div class="card"><pre><?=h(json_encode($res,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?></pre></div><?php endif; ?>
</div></body></html>
