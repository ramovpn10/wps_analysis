<?php
session_start(); require __DIR__.'/common.php';
$data=raw_data(); $rows=$data?rows($data):[]; $records=[];
foreach($rows as $i=>$line){
 if($i===0 || $line==='-' || $line==='') continue;
 $f=explode("\t",$line);
 if(count($f)>=14){
  $records[]=['line'=>$i+1,'amount'=>$f[0],'account'=>$f[1],'name'=>$f[2],
  'ref'=>$f[12]??'','date'=>$f[13]??'','middle'=>$f[10]??'','serial'=>$f[11]??''];
 }
}
$groups=[];
foreach($records as $r){
 $key=$r['name'].'|'.$r['account']; $groups[$key][]=$r['middle'];
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>الأنماط</title><style>
body{margin:0;background:#f3f5f7;font-family:Arial}.wrap{max-width:1180px;margin:30px auto;padding:0 18px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:18px;margin-bottom:16px}
table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #eaecf0}pre{background:#101828;color:#f9fafb;padding:15px;border-radius:12px;overflow:auto}
</style></head><body><div class="wrap"><div class="card"><a href="index.php">الرئيسية</a></div>
<div class="card"><h2>تحليل الأنماط المشتركة</h2><p>هذا التحليل يستخرج العلاقات الظاهرة من الملف الحالي فقط.</p>
<?php if(!$data): ?><p>ارفع ملفاً أولاً.</p><?php else: ?>
<table><tr><th>الاسم/الرمز</th><th>الحساب</th><th>قيم حقل الهوية/المعرف عبر الظهور</th></tr>
<?php foreach($groups as $k=>$vals){[$n,$acc]=explode('|',$k,2);?><tr><td><?=h($n)?></td><td><?=h($acc)?></td><td><?=h(implode(' , ',$vals))?></td></tr><?php } ?>
</table>
<div class="card" style="margin-top:16px"><h3>السجلات</h3><pre><?=h(json_encode($records,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?></pre></div>
<?php endif; ?></div></div></body></html>
