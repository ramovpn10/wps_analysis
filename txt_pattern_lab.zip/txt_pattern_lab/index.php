<?php
session_start();
$notice = $_SESSION['notice'] ?? '';
unset($_SESSION['notice']);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>مختبر تحليل TXT</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,Tahoma,sans-serif;background:#f3f5f7;color:#101828}
.wrap{max-width:1180px;margin:35px auto;padding:0 18px}
.hero,.card{background:#fff;border:1px solid #e4e7ec;border-radius:18px;box-shadow:0 6px 24px rgba(16,24,40,.06)}
.hero{padding:28px}.hero h1{margin:0 0 8px;font-size:30px}.hero p{margin:0;color:#667085}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:18px}
.card{padding:20px}.card h3{margin-top:0}.nav a{display:block;text-decoration:none;color:#101828;margin:8px 0;padding:12px;border-radius:12px;background:#f2f4f7}
.notice{margin-top:18px;background:#fffaeb;border:1px solid #fedf89;border-radius:12px;padding:12px}
.small{font-size:13px;color:#667085}
@media(max-width:850px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
<section class="hero">
<h1>مختبر تحليل بنية ملفات TXT</h1>
<p>رفع، فحص، مقارنة، واختبار الأنماط المكتشفة في الملفات المرفوعة.</p>
<?php if($notice): ?><div class="notice"><?=htmlspecialchars($notice)?></div><?php endif; ?>
</section>

<div class="grid">
<section class="card">
<h3>1) رفع ملف</h3>
<p class="small">يحفظ الملف كما هو ويقيس البايتات دون إعادة تنسيق.</p>
<form action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="txtfile" accept=".txt,text/plain" required><br><br>
<button>رفع وفحص</button>
</form>
</section>

<section class="card nav">
<h3>2) أدوات الفحص</h3>
<a href="inspect.php">الفحص الحرفي</a>
<a href="compare.php">مقارنة ملفين بايتياً</a>
<a href="patterns.php">تحليل الأنماط المشتركة</a>
</section>

<section class="card nav">
<h3>3) المختبر التجريبي</h3>
<a href="sandbox.php">تجربة منطق البيانات الوهمية</a>
<p class="small">المختبر لا ينشئ ملفاً صالحاً للبنك ولا يولد هويات/حسابات حقيقية.</p>
</section>
</div>
</div>
</body>
</html>
