<?php
function raw_data(): string {
    if (empty($_SESSION['data_b64'])) return '';
    $d = base64_decode($_SESSION['data_b64'], true);
    return $d === false ? '' : $d;
}
function rows(string $data): array {
    $x = str_ends_with($data, "\n") ? substr($data,0,-1) : $data;
    return $x === '' ? [] : explode("\n",$x);
}
function exact_fields(string $line): array { return explode("\t",$line); }
function inspect_data(string $data): array {
    $r = rows($data);
    $detail = [];
    foreach($r as $i=>$line){
        if($i===0 || $line==='-' || $i===count($r)-1) continue;
        $detail[] = ['line'=>$i+1,'bytes'=>strlen($line),'tabs'=>substr_count($line,"\t"),
            'field_lengths'=>array_map('strlen',exact_fields($line))];
    }
    return [
        'bytes'=>strlen($data),
        'bom'=>str_starts_with($data,"\xEF\xBB\xBF"),
        'ascii_only'=>!preg_match('/[^\x00-\x7F]/',$data),
        'crlf'=>substr_count($data,"\r\n"),
        'lf'=>substr_count($data,"\n"),
        'tabs'=>substr_count($data,"\t"),
        'rows'=>count($r),
        'header_bytes'=>count($r)?strlen($r[0]):0,
        'header_fields'=>count($r)?count(exact_fields($r[0])):0,
        'separator'=>in_array('-',$r,true),
        'details'=>$detail,
        'last_line_bytes'=>count($r)?strlen($r[count($r)-1]):0
    ];
}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
