<?php
session_start();
if(!isset($_FILES['txtfile']) || $_FILES['txtfile']['error']!==UPLOAD_ERR_OK){
 $_SESSION['notice']='تعذر رفع الملف.'; header('Location:index.php'); exit;
}
$f=$_FILES['txtfile'];
if(strtolower(pathinfo($f['name'],PATHINFO_EXTENSION))!=='txt'){
 $_SESSION['notice']='يسمح فقط بملفات TXT.'; header('Location:index.php'); exit;
}
$data=file_get_contents($f['tmp_name']);
$_SESSION['data_b64']=base64_encode($data);
$_SESSION['filename']=basename($f['name']);
$_SESSION['notice']='تم رفع الملف بدون أي تعديل.'; 
header('Location:inspect.php'); exit;
