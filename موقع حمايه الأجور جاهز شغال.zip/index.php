<?php
// بدء الجلسة الأمنية
session_start();

// التحقق: إذا لم يكن المستخدم قد سجل دخوله، يتم تحويله فوراً لصفحة تسجيل الدخول
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// تسجيل الخروج عند الضغط على الرابط
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>توليد ملف الأجور - مطابق لمواصفات مدد</title>
    <style>
        body {
            background-color: #f7f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }
        .app-container {
            background-color: #ffffff;
            width: 100%;
            max-width: 450px;
            padding: 35px 25px;
            border-radius: 24px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.04);
            box-sizing: border-box;
        }
        h2 {
            text-align: center;
            color: #555555;
            font-size: 18px;
            margin-top: 0;
            margin-bottom: 35px;
            font-weight: 500;
        }
        .input-group {
            margin-bottom: 22px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #2d2d2d;
            font-size: 14px;
            font-weight: 600;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            box-sizing: border-box;
            outline: none;
            background-color: #ffffff;
            color: #333333;
            transition: border-color 0.2s ease;
        }
        input[type="text"]:focus, input[type="number"]:focus, textarea:focus {
            border-color: #3b5bdb;
        }
        textarea {
            height: 160px;
            resize: vertical;
            direction: ltr;
            text-align: left;
            font-family: monospace;
        }
        .buttons-row {
            display: flex;
            gap: 12px;
            margin-top: 30px;
            flex-direction: row;
        }
        button {
            flex: 1;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s ease, opacity 0.2s ease;
        }
        button:active {
            opacity: 0.85;
        }
        .btn-generate {
            background-color: #3b5bdb;
            color: white;
        }
        .btn-generate:hover {
            background-color: #2b49c4;
        }
        .btn-delete {
            background-color: #e0e0e0;
            color: #333333;
        }
        .btn-delete:hover {
            background-color: #d2d2d2;
        }
    </style>
</head>
<body>

<div class="app-container">
    <a href="?logout=true" style="position: absolute; top: 15px; left: 20px; color: #e03131; text-decoration: none; font-size: 13px; font-weight: 600;">تسجيل الخروج</a>
    <h2>توليد ملف الأجور من النص مباشرة</h2>
    
    <input type="hidden" id="companyCode" value="00064009">
    <input type="hidden" id="companyIban" value="SA1580000305608016256457">

    <div class="input-group">
        <label>الرقم الموحد</label>
        <input type="text" id="unifiedNumber" value="" placeholder="أدخل الرقم الموحد">
    </div>

    <div class="input-group">
        <label>راتب السعودي</label>
        <input type="number" id="saudiSalary" value="" placeholder="أدخل راتب السعودي">
    </div>

    <div class="input-group">
        <label>راتب المقيم</label>
        <input type="number" id="residentSalary" value="" placeholder="أدخل راتب المقيم">
    </div>

    <div class="input-group">
        <label>النص</label>
        <textarea id="idList" placeholder="أدخل أرقام الهويات هنا..."></textarea>
    </div>

    <div class="buttons-row">
        <button class="btn-generate" onclick="generateFile()">توليد الملف</button>
        <button class="btn-delete" onclick="clearFields()">حذف</button>
    </div>
</div>

<script>
function clearFields() {
    document.getElementById('unifiedNumber').value = '';
    document.getElementById('saudiSalary').value = '';
    document.getElementById('residentSalary').value = '';
    document.getElementById('idList').value = '';
}

function formatAmount16(amount) {
    let formatted = parseFloat(amount).toFixed(2).replace('.', ',');
    return formatted.padStart(16, '0');
}

function formatAmount13(amount) {
    let formatted = parseFloat(amount).toFixed(2).replace('.', ',');
    return formatted.padStart(13, '0');
}

async function generateIban(id, unifiedNumber, companyIban) {
    const cleanCompanyIban = companyIban.trim().replace(/\s+/g, '');
    const middlePart = cleanCompanyIban.substring(4, 20); 
    
    const source = unifiedNumber.trim() + "|" + id.trim();
    const data = new TextEncoder().encode(source);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const digits = hashArray.map(x => x % 10).join('');
    
    const checkDigits = digits.substring(0, 2); 
    const variableSuffix = digits.substring(2, 6); 
    
    return "SA" + checkDigits + middlePart + variableSuffix;
}

function generateEmployeeCode(isSaudi, index) {
    const suffixPool = ['3', '2', '6', '7', '4', '8', '9', '1', 'A', 'B', 'C', '5', 'D', 'E'];
    const suffix = suffixPool[index % suffixPool.length]; 
    
    const prefix = isSaudi ? 'M' : 'W'; 
    
    return `${prefix} ${suffix}`;
}

async function generateFile() {
    const unifiedNumber = document.getElementById('unifiedNumber').value.trim();
    const companyCode = document.getElementById('companyCode').value.trim();
    const companyIban = document.getElementById('companyIban').value.trim();
    
    const saudiSalary = parseFloat(document.getElementById('saudiSalary').value) || 0;
    const residentSalary = parseFloat(document.getElementById('residentSalary').value) || 0;
    const idListRaw = document.getElementById('idList').value;

    const ids = idListRaw.split(/\r?\n/).map(id => id.trim()).filter(id => id.length > 0);

    if (!unifiedNumber) {
        alert('الرجاء إدخل الرقم الموحد أولاً!');
        return;
    }

    if (ids.length === 0) {
        alert('لم يتم العثور على أرقام هويات!');
        return;
    }

    let fileRefInput = "";
    if (unifiedNumber === "12-4043297") {
        fileRefInput = "12-4043297  01-2";
    } else if (unifiedNumber === "09-176612") {
        fileRefInput = "4180534 176612 4";
    } else {
        fileRefInput = unifiedNumber + "  01-2";
    }

    const startCentralRef = 1086237612 + Math.floor(Math.random() * 100); 

    const dateObj = new Date();
    const dateStr = dateObj.getFullYear() +
        String(dateObj.getMonth() + 1).padStart(2, '0') +
        String(dateObj.getDate()).padStart(2, '0');
    
    const shortDate = dateStr.slice(2); 

    const baseTransRef = 7467925 + Math.floor(Math.random() * 100); 

    let totalAmount = 0;
    let recordsText = "";

    const fileRefPad = fileRefInput.padEnd(16, ' ');
    const headerCompanyCode = companyCode.padEnd(10, ' ');

    for (let index = 0; index < ids.length; index++) {
        const id = ids[index];
        const isSaudi = id.startsWith('1');
        const currentSalary = isSaudi ? saudiSalary : residentSalary;

        totalAmount += currentSalary;

        const formattedSalary16 = formatAmount16(currentSalary);
        const formattedSalary13 = formatAmount13(currentSalary);
        
        const employeeCodeStr = generateEmployeeCode(isSaudi, index);

        const iban = await generateIban(id, unifiedNumber, companyIban);
        const centralRef = startCentralRef + index;
        
        const transactionRef = `${shortDate}524${baseTransRef + index}`;

        const ibanPad = iban.padEnd(34, ' ');
        const codePad = employeeCodeStr.padEnd(87, ' ');
        const rjhiPad = 'RJHI'.padEnd(46, ' ');
        const refPad = (`Centralization Ref:${centralRef}`).padEnd(115, ' ');

        // تم التعديل هنا بدقة: إزالة العمود الفارغ والجدولة الزائدة لتصبح الأعمدة 14 عموداً بالوفاء والتمام
        recordsText += `${formattedSalary16}\t${ibanPad}\t${codePad}\t${rjhiPad}\t${refPad}\t      \t${formattedSalary13}\t0000000000,00\t0000000000,00\t0000000000,00\t${id}\t${transactionRef}\tSuccess \t${dateStr}\r\n`;
    }

    const formattedTotal16 = formatAmount16(totalAmount);
    
    const header = `PMS\t${headerCompanyCode}\t${companyIban}\tSAR\t${dateStr}\t${formattedTotal16}\t${dateStr}\t${fileRefPad}\tP000  \t${unifiedNumber}\r\n`;

    const fileBody = header + recordsText;

    const encodedB64Content = btoa(unescape(encodeURIComponent(fileBody)));

    try {
        const response = await fetch("sign.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ b64content: encodedB64Content })
        });

        if(!response.ok) {
            throw new Error("خطأ في الاتصال بملف التوقيع");
        }

        const signature = await response.text();
        
        const fileContent = fileBody + "-\r\n" + signature.trim();

        const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        a.download = `${companyCode}_W_${dateStr}.txt`;
        
        document.body.appendChild(a);
        a.click();

        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 0);
    } catch(err) {
        alert("حدث خطأ في عملية التوقيع. يرجى التأكد من أن ملف sign.php يعمل بشكل صحيح.");
        console.error(err);
    }
}
</script>

</body>
</html>
