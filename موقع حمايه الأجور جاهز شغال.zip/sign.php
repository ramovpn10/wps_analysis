<?php
// استقبال النص المشفر بـ Base64
$b64Content = $_POST['b64content'] ?? '';

if (trim($b64Content) === '') {
    die('NO_CONTENT');
}

// فك التشفير للعودة للنص الأصلي
$fileContent = base64_decode($b64Content);

$privateKey = file_get_contents(__DIR__ . '/private.pem');

openssl_sign(
    $fileContent,
    $signature,
    $privateKey,
    OPENSSL_ALGO_SHA256
);

echo base64_encode($signature);