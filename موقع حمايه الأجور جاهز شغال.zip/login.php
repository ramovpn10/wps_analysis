<?php
session_start();

// تعيين كلمة السر (يمكنك تغييرها من هنا)
$PASSWORD = "nora"; 

// إذا كان المستخدم مسجلاً للدخول بالفعل، يتم توجيهه مباشرة للرئيسية
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: index.php");
    exit;
}

// التحقق من كلمة السر عند إرسال النموذج
if (isset($_POST['login_password'])) {
    if ($_POST['login_password'] === $PASSWORD) {
        $_SESSION['logged_in'] = true;
        header("Location: index.php");
        exit;
    } else {
        $error_message = "كلمة السر التي أدخلتها غير صحيحة!";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام حماية الأجور - تسجيل الدخول</title>
    <style>
        body {
            background-color: #f7f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            background-color: #ffffff;
            width: 100%;
            max-width: 360px;
            padding: 40px 30px;
            border-radius: 24px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.04);
            text-align: center;
            box-sizing: border-box;
        }
        h3 {
            margin-top: 0;
            margin-bottom: 25px;
            color: #2d2d2d;
            font-size: 18px;
            font-weight: 600;
        }
        input[type="password"] {
            width: 100%;
            padding: 14px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-size: 16px;
            box-sizing: border-box;
            outline: none;
            text-align: center;
            margin-bottom: 15px;
        }
        input[type="password"]:focus {
            border-color: #3b5bdb;
        }
        button {
            width: 100%;
            padding: 14px;
            background-color: #3b5bdb;
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        button:hover {
            background-color: #2b49c4;
        }
        .error-msg {
            color: #e03131;
            font-size: 14px;
            margin-bottom: 15px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h3>تسجيل الدخول </h3>
        
        <?php if (isset($error_message)): ?>
            <div class="error-msg"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="password" name="login_password" placeholder="أدخل كلمة السر" required autofocus>
            <button type="submit">دخول</button>
        </form>
    </div>
</body>
</html>
