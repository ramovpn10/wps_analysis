<?php
session_start();

function fail($msg) {
    $_SESSION['error'] = $msg;
    header('Location: index.php');
    exit;
}

$seed1 = trim($_POST['seed1'] ?? '');
$seed2 = trim($_POST['seed2'] ?? '');
$seed3 = trim($_POST['seed3'] ?? '');
$company = trim($_POST['company'] ?? '');
$date = trim($_POST['date'] ?? '');
$count = (int)($_POST['count'] ?? 9);

if ($seed1 === '' || $seed2 === '' || $seed3 === '' || $company === '') fail('أكمل جميع الحقول.');
if (!preg_match('/^\\d{8}$/', $date)) fail('التاريخ يجب أن يكون 8 أرقام.');
if ($count < 1 || $count > 9) fail('عدد السجلات من 1 إلى 9.');

$names = ['A','B','C','D','E','F','G','H','I'];
$ibanSeeds = [
    'TEST-IBAN-01','TEST-IBAN-02','TEST-IBAN-03','TEST-IBAN-04','TEST-IBAN-05',
    'TEST-IBAN-06','TEST-IBAN-07','TEST-IBAN-08','TEST-IBAN-09'
];

// Synthetic only: clearly non-bank values.
$records = [];
$baseRef = 9000000000;
for ($i = 0; $i < $count; $i++) {
    $name = $names[$i];
    $syntheticId = 'ID-TEST-' . str_pad((string)($i + 1), 4, '0', STR_PAD_LEFT);
    $ref = (string)($baseRef + $i);
    $records[] = [
        'code' => $name,
        'iban' => $ibanSeeds[$i],
        'id' => $syntheticId,
        'ref' => $ref,
        'amount' => 400.00
    ];
}

// Tie the first three inputs into the simulator without pretending they are national IDs.
$seeds = [$seed1, $seed2, $seed3];
for ($i = 0; $i < min(3, count($records)); $i++) {
    $records[$i]['source_seed'] = $seeds[$i];
}

$total = array_sum(array_column($records, 'amount'));

$out = [];
$out[] = "SIMU\t".$company."\t".sprintf('TEST-%08d', 1)."\t".$date."\t".number_format($total, 2, '.', '');
foreach ($records as $r) {
    $out[] = implode("\t", [
        $r['code'],
        $r['iban'],
        $r['id'],
        $r['amount'],
        $r['ref'],
        'TEST_SUCCESS',
        $date
    ]);
}
$out[] = '-';
$unsigned = implode("\n", $out) . "\n";

$_SESSION['unsigned'] = $unsigned;
$_SESSION['records'] = $records;
$_SESSION['meta'] = ['company'=>$company, 'date'=>$date, 'total'=>$total];

file_put_contents(__DIR__ . '/sandbox_output.txt', $unsigned);

header('Location: sign.php');
exit;
