<?php
$reference = '';
$generated = file_exists(__DIR__.'/sandbox_output.txt') ? file_get_contents(__DIR__.'/sandbox_output.txt') : '';
$report = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reference = $_POST['reference'] ?? '';
    $report = [
        'generated_bytes' => strlen($generated),
        'reference_bytes' => strlen($reference),
        'line_count_generated' => substr_count(trim($generated), "\n") + ($generated !== '' ? 1 : 0),
        'line_count_reference' => $reference === '' ? 0 : substr_count(trim($reference), "\n") + 1,
        'first_difference' => null
    ];
    $min = min(strlen($generated), strlen($reference));
    for ($i = 0; $i < $min; $i++) {
        if ($generated[$i] !== $reference[$i]) {
            $report['first_difference'] = $i;
            break;
        }
    }
    if ($report['first_difference'] === null && strlen($generated) !== strlen($reference)) {
        $report['first_difference'] = $min;
    }
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><title>المقارنة</title></head>
<body>
<h2>صفحة المقارنة</h2>
<p>قارن فقط ملفات الاختبار الوهمية.</p>
<form method="post">
<textarea name="reference" rows="18" cols="110" placeholder="ألصق ملفًا تجريبيًا هنا"></textarea><br>
<button type="submit">قارن</button>
</form>
<?php if ($report): ?>
<hr>
<pre><?=htmlspecialchars(json_encode($report, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE))?></pre>
<?php endif; ?>
<h3>الملف التجريبي الحالي</h3>
<pre><?=htmlspecialchars($generated)?></pre>
<a href="sign.php">صفحة التوقيع</a>
</body></html>
