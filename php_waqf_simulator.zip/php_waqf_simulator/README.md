# PHP Data Pattern Simulator (Sandbox Only)

This is a non-production simulator for studying repeated file structures.
It uses synthetic IDs/IBAN-like values and creates a test signature only.

Pages:
1. index.php      - input
2. engine.php     - generate synthetic records
3. compare.php    - compare generated text with a reference text
4. sign.php       - create/verify a demo cryptographic signature

Important:
- Do NOT use real national IDs, real bank accounts, or live payroll/bank files.
- The signature is for sandbox/testing only and is not compatible with any bank system.
