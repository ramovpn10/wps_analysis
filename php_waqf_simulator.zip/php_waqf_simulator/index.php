<?php
session_start();
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><title>محاكي البنية</title></head>
<body>
<h2>محاكي بنية الملفات - بيانات وهمية</h2>
<form method="post" action="engine.php">
  <label>معرف وهمي 1 <input name="seed1" value="TEST-001" required></label><br>
  <label>معرف وهمي 2 <input name="seed2" value="TEST-002" required></label><br>
  <label>معرف وهمي 3 <input name="seed3" value="TEST-003" required></label><br>
  <label>رقم منشأة وهمي <input name="company" value="00000001" required></label><br>
  <label>التاريخ <input name="date" value="<?=htmlspecialchars(date('Ymd'))?>" pattern="\\d{8}" required></label><br>
  <label>عدد السجلات <input type="number" name="count" value="9" min="1" max="9" required></label><br><br>
  <button type="submit">إنشاء ملف تجريبي</button>
</form>
<?php if ($error): ?><p style="color:#b00"><?=htmlspecialchars($error)?></p><?php endif; ?>
<p>هذه الصفحة لا تتصل بأي بنك ولا تنشئ ملفًا صالحًا للإرسال للبنك.</p>
</body></html>
