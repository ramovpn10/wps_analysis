<?php
session_start();

$unsigned = $_SESSION['unsigned'] ?? (file_exists(__DIR__.'/sandbox_output.txt') ? file_get_contents(__DIR__.'/sandbox_output.txt') : '');
$message = '';
$signature = '';
$verified = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $unsigned !== '') {
    // Sandbox-only key pair. We generate an ephemeral key if one does not exist.
    $keyPath = __DIR__ . '/sandbox_private.pem';
    if (!file_exists($keyPath)) {
        $key = openssl_pkey_new([
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
            'private_key_bits' => 2048
        ]);
        openssl_pkey_export($key, $private);
        file_put_contents($keyPath, $private);
    }

    $private = file_get_contents($keyPath);
    $ok = openssl_sign($unsigned, $raw, $private, OPENSSL_ALGO_SHA256);
    if ($ok) {
        $signature = base64_encode($raw);
        $_SESSION['signature'] = $signature;
        file_put_contents(__DIR__ . '/sandbox_signature.b64', $signature);
        $message = 'تم إنشاء توقيع تجريبي فقط.';
    }
}

if (isset($_POST['verify']) && $unsigned !== '' && file_exists(__DIR__.'/sandbox_signature.b64')) {
    $keyPath = __DIR__ . '/sandbox_private.pem';
    $private = file_get_contents($keyPath);
    $pkey = openssl_pkey_get_private($private);
    $details = openssl_pkey_get_details($pkey);
    $public = $details['key'];
    $signature = base64_decode(file_get_contents(__DIR__.'/sandbox_signature.b64'), true);
    $verified = openssl_verify($unsigned, $signature, $public, OPENSSL_ALGO_SHA256) === 1;
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><title>التوقيع التجريبي</title></head>
<body>
<h2>صفحة التوقيع التجريبي</h2>
<p>هذه الصفحة تستخدم RSA-SHA256 على بيانات وهمية فقط، وليست توقيعًا مصرفيًا ولا يمكن تقديمه للبنك.</p>

<form method="post">
  <button type="submit">توقيع الملف التجريبي</button>
  <button type="submit" name="verify" value="1">التحقق من التوقيع</button>
</form>

<?php if ($message): ?><p><?=htmlspecialchars($message)?></p><?php endif; ?>
<?php if ($verified !== null): ?><p>نتيجة التحقق: <strong><?= $verified ? 'صحيح' : 'فشل' ?></strong></p><?php endif; ?>

<h3>المحتوى الموقع</h3>
<pre><?=htmlspecialchars($unsigned)?></pre>

<?php if ($signature): ?>
<h3>Base64 Signature (Sandbox)</h3>
<textarea rows="8" cols="110"><?=htmlspecialchars($signature)?></textarea>
<?php endif; ?>

<p><a href="compare.php">المقارنة</a> | <a href="index.php">البداية</a></p>
</body></html>
