Wage File Signature Lab - InfinityFree

ارفع جميع الملفات الموجودة في هذا المجلد مباشرة إلى htdocs.

الصفحة الرئيسية:
index.php

المحلل:
analyzer.php

الموقع مختبر تجريبي. لا يعتبر أي توقيع هنا توقيع Mudad الرسمي.

تشغيل محلي اختياري:
php -S 127.0.0.1:8080 -t .
