<?php
declare(strict_types=1);
function h($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }

function normalize_eol(string $data,string $mode): string {
    if($mode==='original') return $data;
    $data=str_replace(["\r\n","\r"],"\n",$data);
    return $mode==='crlf' ? str_replace("\n","\r\n",$data) : $data;
}

function extract_payload(string $data): string {
    $p=strrpos($data,"\n-");
    if($p===false) return $data;
    $candidate=trim(substr($data,$p+2));
    if($candidate!=='' && preg_match('/^[A-Za-z0-9+\/=]+$/',$candidate))
        return substr($data,0,$p+1);
    return $data;
}

function process_sign($file,array $post): array {
    if(!$file || ($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)
        throw new RuntimeException('اختر ملف TXT صالحًا.');
    if(($file['size']??0)>10*1024*1024)
        throw new RuntimeException('حجم الملف أكبر من 10MB.');
    $raw=file_get_contents($file['tmp_name']);
    if($raw===false) throw new RuntimeException('تعذر قراءة الملف.');

    $raw=normalize_eol($raw,$post['eol']??'original');
    $payload=extract_payload($raw);
    $signData=$payload;
    $includeDash=isset($post['include_dash']);
    if($includeDash) $signData.='-';

    $alg=$post['algorithm']??'sha256';
    switch($alg){
        case 'sha256':
            $sig=base64_encode(hash('sha256',$signData,true));
            $label='SHA-256 digest → Base64'; break;
        case 'sha512':
            $sig=base64_encode(hash('sha512',$signData,true));
            $label='SHA-512 digest → Base64'; break;
        case 'hmac-sha256':
            $key=(string)($post['secret']??'');
            if($key==='') throw new RuntimeException('أدخل HMAC Secret.');
            $sig=base64_encode(hash_hmac('sha256',$signData,$key,true));
            $label='HMAC-SHA256 → Base64'; break;
        case 'rsa-sha256':
            $pem=(string)($post['private_key']??'');
            if($pem==='') throw new RuntimeException('ألصق RSA Private Key بصيغة PEM.');
            $key=openssl_pkey_get_private($pem);
            if($key===false) throw new RuntimeException('RSA Private Key غير صالح.');
            if(!openssl_sign($signData,$bin,$key,OPENSSL_ALGO_SHA256))
                throw new RuntimeException('تعذر إنشاء RSA signature.');
            $sig=base64_encode($bin);
            $label='RSA-SHA256 → Base64'; break;
        default: throw new RuntimeException('خوارزمية غير معروفة.');
    }

    $mode=$post['eol']??'original';
    $eol=$mode==='crlf'?"\r\n":($mode==='lf'?"\n":detect_eol($payload));
    if($eol==='MIXED') $eol="\n";
    $out=rtrim($payload,"\r\n").$eol."-".$eol.$sig.$eol;

    $base=preg_replace('/[^A-Za-z0-9._-]/','_',basename($file['name']));
    $filename=pathinfo($base,PATHINFO_FILENAME).'_signed.txt';
    $dir=__DIR__.'/output';
    if(!is_dir($dir)) mkdir($dir,0755,true);
    file_put_contents($dir.'/'.$filename,$out);

    return [
        'filename'=>$filename,'algorithm'=>$label,'payload_bytes'=>strlen($signData),
        'sig_chars'=>strlen($sig),'sig_bytes'=>strlen(base64_decode($sig,true)?:''),
        'eol'=>$mode==='original'?'ORIGINAL':strtoupper($mode),
        'dash'=>$includeDash?'YES':'NO'
    ];
}

function detect_eol(string $d): string {
    $crlf=substr_count($d,"\r\n");
    $lf=substr_count($d,"\n")-$crlf;
    $cr=substr_count(str_replace("\r\n",'',$d),"\r");
    if($crlf>0 && $lf===0 && $cr===0) return "\r\n";
    if($lf>0 && $crlf===0 && $cr===0) return "\n";
    if($cr>0 && $crlf===0 && $lf===0) return "\r";
    return 'MIXED';
}