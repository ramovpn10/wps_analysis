<?php
declare(strict_types=1);
require __DIR__.'/functions.php';
$report=null;$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
   $a=$_FILES['accepted']??null; $r=$_FILES['rejected']??null;
   if(!$a||!$r||$a['error']!==UPLOAD_ERR_OK||$r['error']!==UPLOAD_ERR_OK) throw new RuntimeException('ارفع الملف المقبول والمرفوض.');
   $A=file_get_contents($a['tmp_name']); $R=file_get_contents($r['tmp_name']);
   if($A===false||$R===false) throw new RuntimeException('تعذر قراءة الملفات.');
   $n=min(strlen($A),strlen($R)); $first=null;$diff=0;
   for($i=0;$i<$n;$i++){if($A[$i]!==$R[$i]){$diff++;if($first===null)$first=$i;}}
   $diff+=abs(strlen($A)-strlen($R));
   $last=null;
   for($i=$n-1;$i>=0;$i--){if($A[$i]!==$R[$i]){$last=$i;break;}}
   if($last===null && strlen($A)!==strlen($R)) $last=$n;
   $report=[
    'accepted_size'=>strlen($A),'rejected_size'=>strlen($R),
    'accepted_sha256'=>hash('sha256',$A),'rejected_sha256'=>hash('sha256',$R),
    'first'=>$first,'last'=>$last,'diff'=>$diff,
    'accepted_eol'=>detect_eol($A),'rejected_eol'=>detect_eol($R),
    'accepted_b64'=>last_b64($A),'rejected_b64'=>last_b64($R)
   ];
 }catch(Throwable $e){$error=$e->getMessage();}
}
function last_b64(string $d): array{
 $p=strrpos($d,"\n-"); if($p===false)return ['present'=>false,'chars'=>0,'bytes'=>0];
 $c=trim(substr($d,$p+2));
 $b=base64_decode($c,true);
 return ['present'=>(bool)$b,'chars'=>strlen($c),'bytes'=>$b===false?0:strlen($b)];
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Forensic Analyzer</title><link rel="stylesheet" href="style.css"></head><body><main class="container"><section class="card">
<h1>Wage File Forensic Analyzer</h1><p class="muted">مقارنة binary أولية بين ملف مقبول وملف مرفوض.</p>
<?php if($error):?><div class="error"><?=h($error)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data">
<label>Accepted TXT</label><input type="file" name="accepted" accept=".txt" required>
<label>Rejected TXT</label><input type="file" name="rejected" accept=".txt" required>
<button type="submit">تحليل الفرق</button></form>
<?php if($report):?><div class="success"><h2>النتيجة</h2>
<p>Accepted size: <?=h($report['accepted_size'])?></p><p>Rejected size: <?=h($report['rejected_size'])?></p>
<p>Accepted SHA-256: <code><?=h($report['accepted_sha256'])?></code></p>
<p>Rejected SHA-256: <code><?=h($report['rejected_sha256'])?></code></p>
<p>First differing byte offset: <b><?=h($report['first']===null?'NONE':$report['first'])?></b></p>
<p>Last differing byte offset: <b><?=h($report['last']===null?'NONE':$report['last'])?></b></p>
<p>Differing bytes: <b><?=h($report['diff'])?></b></p>
<p>EOL Accepted: <?=h($report['accepted_eol'])?> | Rejected: <?=h($report['rejected_eol'])?></p>
<p>Accepted signature: <?=h($report['accepted_b64']['chars'])?> Base64 / <?=h($report['accepted_b64']['bytes'])?> decoded bytes</p>
<p>Rejected signature: <?=h($report['rejected_b64']['chars'])?> Base64 / <?=h($report['rejected_b64']['bytes'])?> decoded bytes</p>
</div><?php endif;?>
<p><a href="index.php">← العودة للتوقيع</a></p></section></main></body></html>