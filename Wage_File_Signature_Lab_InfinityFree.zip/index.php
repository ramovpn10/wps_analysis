<?php
declare(strict_types=1);
require __DIR__.'/functions.php';
$result=null; $error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        $result=process_sign($_FILES['wage_file']??null, $_POST);
    }catch(Throwable $e){ $error=$e->getMessage(); }
}
?>
<!doctype html>
<html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Wage File Signature Lab</title><link rel="stylesheet" href="style.css"></head>
<body><main class="container"><section class="card">
<h1>Wage File Signature Lab</h1>
<p class="muted">مختبر تجريبي لتحليل احتمالات التوقيع وبنية ملف الأجور.</p>
<div class="warning">تنبيه: النتائج تجريبية ولا تعني أن الخوارزمية المستخدمة هي خوارزمية التوقيع الرسمية للجهة.</div>
<?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
<label>ملف الأجور TXT</label>
<input type="file" name="wage_file" accept=".txt,text/plain" required>
<div class="grid">
<div><label>طريقة التوقيع</label>
<select name="algorithm" id="algorithm" onchange="toggleFields()">
<option value="sha256">SHA-256 → Base64</option>
<option value="sha512">SHA-512 → Base64</option>
<option value="hmac-sha256">HMAC-SHA256 → Base64</option>
<option value="rsa-sha256">RSA-SHA256 → Base64</option>
</select></div>
<div><label>Line Ending</label>
<select name="eol"><option value="original">الأصلي</option><option value="lf">LF</option><option value="crlf">CRLF</option></select></div>
</div>
<label class="check"><input type="checkbox" name="include_dash"> التوقيع يشمل <code>-</code></label>
<p class="hint">إذا لم تحددها: التوقيع على البيانات قبل منطقة الشرطة. إذا حددتها: تتم إضافة الشرطة إلى الـpayload.</p>
<div id="hmac"><label>HMAC Secret</label><input type="password" name="secret"></div>
<div id="rsa"><label>RSA Private Key PEM</label><textarea name="private_key" placeholder="-----BEGIN PRIVATE KEY-----"></textarea></div>
<button type="submit">إنشاء ملف تجريبي</button>
</form>
<?php if($result): ?><div class="success">
<h2>تم الإنشاء</h2>
<p>الخوارزمية: <b><?=h($result['algorithm'])?></b></p>
<p>Signed payload: <?=h($result['payload_bytes'])?> bytes</p>
<p>Signature: <?=h($result['sig_chars'])?> Base64 chars / <?=h($result['sig_bytes'])?> decoded bytes</p>
<p>Line Ending: <?=h($result['eol'])?></p>
<p>Dash included: <?=h($result['dash'])?></p>
<a class="download" href="output/<?=rawurlencode($result['filename'])?>" download>تحميل الملف</a>
</div><?php endif; ?>
</section></main>
<script>
function toggleFields(){
 const a=document.getElementById('algorithm').value;
 document.getElementById('hmac').style.display=a==='hmac-sha256'?'block':'none';
 document.getElementById('rsa').style.display=a==='rsa-sha256'?'block':'none';
} toggleFields();
</script></body></html>