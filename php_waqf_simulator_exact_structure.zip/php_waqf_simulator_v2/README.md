# PHP Synthetic Structure Simulator — Sandbox

This version was rebuilt to match the structural patterns measured from the supplied reference files:

- ASCII-compatible bytes only
- No UTF-8 BOM
- LF (`\n`) line endings only
- TAB (`\t`) separators
- 122-byte header line
- 583-byte detail lines
- 14 detail fields / 13 TABs
- one `-` separator line
- one Base64 signature line that decodes to 256 bytes
- fixed-width spaces/padding matching the measured field widths

The logic is intentionally synthetic:
- no real national IDs
- no real bank accounts
- no real payroll submission format
- no bank-compatible signature

The simulator models the observed *structural relationships* only.
