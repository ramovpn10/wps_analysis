<?php
session_start();

function fail(string $msg): never {
    $_SESSION['error'] = $msg;
    header('Location: index.php');
    exit;
}

function fixed(string $value, int $length, string $pad = ' ', int $direction = STR_PAD_RIGHT): string {
    $value = preg_replace('/[^\x00-\x7F]/', '', $value);
    if (strlen($value) > $length) {
        $value = substr($value, 0, $length);
    }
    return str_pad($value, $length, $pad, $direction);
}

function moneyField(float $amount): string {
    // Synthetic representation matching the measured 16-char amount shape.
    return sprintf('%013d,%02d', (int)floor($amount), (int)round(($amount - floor($amount)) * 100));
}

function f13(float $amount): string {
    return sprintf('%012d,%02d', (int)floor($amount), (int)round(($amount - floor($amount)) * 100));
}

$seed1 = trim($_POST['seed1'] ?? '');
$seed2 = trim($_POST['seed2'] ?? '');
$seed3 = trim($_POST['seed3'] ?? '');
$company = trim($_POST['company'] ?? '');
$date = trim($_POST['date'] ?? '');
$count = (int)($_POST['count'] ?? 9);

if ($seed1 === '' || $seed2 === '' || $seed3 === '' || $company === '') fail('أكمل الحقول.');
if (!preg_match('/^\d{8}$/', $date)) fail('التاريخ يجب أن يكون 8 أرقام.');
if ($count < 1 || $count > 9) fail('عدد السجلات من 1 إلى 9.');

$tokens = ['A','B','C','D','E','F','G','H','I'];
// Synthetic fixed mapping: structure only, not real accounts.
$syntheticAccounts = [
    'A'=>'TEST-ACCT-6297','B'=>'TEST-ACCT-6305','C'=>'TEST-ACCT-6354',
    'D'=>'TEST-ACCT-6495','E'=>'TEST-ACCT-6594','F'=>'TEST-ACCT-6586',
    'G'=>'TEST-ACCT-7535','H'=>'TEST-ACCT-7543','I'=>'TEST-ACCT-7550'
];

// Observed pattern: a stable code/account relationship, while the record ID
// can vary from file to file. Here it is synthetic and deterministic.
$ids = [
    'TEST-ID-1001','TEST-ID-1002','TEST-ID-1003','TEST-ID-1004','TEST-ID-1005',
    'TEST-ID-1006','TEST-ID-1007','TEST-ID-1008','TEST-ID-1009'
];

$seedInputs = [$seed1, $seed2, $seed3];

$records = [];
$tailStart = 45683; // synthetic analogue of the observed contiguous six-digit tail.
$shuffle = range(0, $count - 1);
mt_srand(crc32($seed1.'|'.$seed2.'|'.$seed3.'|'.$date));
shuffle($shuffle);

for ($position = 0; $position < $count; $position++) {
    $slot = $shuffle[$position];
    $code = $tokens[$slot];
    $amount = 400.00;
    if ($position === 0) {
        // Small synthetic fractional variation mirrors the observed "one row differs".
        $amount = 400.34;
    }
    $serialTail = $tailStart + $slot;
    $ref16 = substr($date, 2) . '5319' . str_pad((string)$serialTail, 6, '0', STR_PAD_LEFT);
    $centralRef = (string)(9000000000 + $position);

    $records[] = [
        'amount' => $amount,
        'account' => $syntheticAccounts[$code],
        'code' => $code,
        'id' => $ids[$slot],
        'ref16' => $ref16,
        'central' => $centralRef,
        'seed' => $position < 3 ? $seedInputs[$position] : ''
    ];
}

$total = array_sum(array_column($records, 'amount'));

// Exact observed field widths: 16 / 34 / 140 / 140 / 140 / 6 / 13 / 13 / 13 / 13 / 10 / 16 / 8 / 8
$header = [
    fixed('SIMU', 4),
    fixed($company, 10),
    fixed('TEST-' . substr(hash('sha256', $company), 0, 19), 24),
    fixed('SYN', 3),
    fixed($date, 8),
    fixed(moneyField($total), 16),
    fixed($date, 8),
    fixed('TEST-' . substr(hash('sha256', $seed1.$seed2.$seed3), 0, 11), 16),
    fixed('P000', 6),
    fixed('TEST-' . substr(hash('sha256', $date.$company), 0, 10), 18),
];

$lines = [implode("\t", $header)];

foreach ($records as $r) {
    $detail = [
        fixed(moneyField($r['amount']), 16, '0', STR_PAD_LEFT),
        fixed($r['account'], 34),
        fixed($r['code'], 140),
        fixed('RJHI', 140),
        fixed('TEST-PAYROLL', 140),
        fixed('', 6),
        fixed(f13($r['amount']), 13, '0', STR_PAD_LEFT),
        fixed(f13(0), 13, '0', STR_PAD_LEFT),
        fixed(f13(0), 13, '0', STR_PAD_LEFT),
        fixed(f13(0), 13, '0', STR_PAD_LEFT),
        fixed($r['id'], 10),
        fixed($r['ref16'], 16),
        fixed('Success', 8),
        fixed($date, 8)
    ];
    $line = implode("\t", $detail);
    if (strlen($line) !== 583) {
        fail('فشل فحص الطول الداخلي للسطر التجريبي.');
    }
    $lines[] = $line;
}

$unsigned = implode("\n", $lines) . "\n-\n";
file_put_contents(__DIR__ . '/sandbox_unsigned.txt', $unsigned);

$_SESSION['unsigned'] = $unsigned;
$_SESSION['records'] = $records;
header('Location: sign.php');
exit;
