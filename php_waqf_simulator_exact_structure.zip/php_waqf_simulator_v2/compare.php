<?php
$generated = file_exists(__DIR__.'/sandbox_unsigned.txt') ? file_get_contents(__DIR__.'/sandbox_unsigned.txt') : '';
$result = null;
$reference = '';

function structuralReport(string $b): array {
    $lines = explode("\n", $b);
    $lastEmpty = end($lines) === '' ? array_pop($lines) : false;
    $report = [
        'bytes' => strlen($b),
        'bom' => str_starts_with($b, "\xEF\xBB\xBF"),
        'ascii_only' => !preg_match('/[^\x00-\x7F]/', $b),
        'crlf_count' => substr_count($b, "\r\n"),
        'lf_count' => substr_count($b, "\n"),
        'tab_count' => substr_count($b, "\t"),
        'line_count_including_separator_and_signature' => count($lines),
        'header_length' => isset($lines[0]) ? strlen($lines[0]) : null,
        'header_tabs' => isset($lines[0]) ? substr_count($lines[0], "\t") : null,
        'detail_lengths' => [],
        'detail_tabs' => [],
        'separator_present' => in_array('-', $lines, true),
    ];
    foreach ($lines as $idx => $line) {
        if ($idx === 0 || $line === '-' || $idx === count($lines)-1) continue;
        $report['detail_lengths'][] = strlen($line);
        $report['detail_tabs'][] = substr_count($line, "\t");
    }
    return $report;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reference = $_POST['reference'] ?? '';
    $a = structuralReport($generated);
    $b = structuralReport($reference);
    $result = ['generated' => $a, 'reference' => $b];
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><title>مقارنة البنية</title></head>
<body>
<h2>فحص الترميز والمسافات والبنية</h2>
<p>تُلصق هنا نسخة اختبارية فقط.</p>
<form method="post">
<textarea name="reference" rows="18" cols="120"></textarea><br>
<button type="submit">افحص وقارن</button>
</form>

<?php if ($result): ?>
<pre><?=htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE))?></pre>
<?php endif; ?>

<h3>الملف التجريبي المولد</h3>
<pre><?=htmlspecialchars($generated)?></pre>

<p><a href="sign.php">التوقيع</a></p>
</body>
</html>
