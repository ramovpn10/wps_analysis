<?php
session_start();

$unsigned = $_SESSION['unsigned'] ?? (file_exists(__DIR__.'/sandbox_unsigned.txt') ? file_get_contents(__DIR__.'/sandbox_unsigned.txt') : '');
$message = '';
$signature = '';
$verified = null;

function ensureKeys(): array {
    $path = __DIR__ . '/sandbox_private.pem';
    if (!file_exists($path)) {
        $key = openssl_pkey_new([
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
            'private_key_bits' => 2048
        ]);
        if (!$key || !openssl_pkey_export($key, $private)) {
            throw new RuntimeException('تعذر إنشاء المفتاح التجريبي.');
        }
        file_put_contents($path, $private, LOCK_EX);
    }
    return [$path, file_get_contents($path)];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sign']) && $unsigned !== '') {
    [$keyPath, $private] = ensureKeys();
    if (!openssl_sign($unsigned, $raw, $private, OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('فشل توقيع البيانات التجريبية.');
    }
    $signature = base64_encode($raw);
    file_put_contents(__DIR__ . '/sandbox_signature.b64', $signature, LOCK_EX);
    $message = sprintf(
        'تم إنشاء توقيع تجريبي. decoded bytes=%d, base64 chars=%d.',
        strlen($raw), strlen($signature)
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify']) && $unsigned !== '' && file_exists(__DIR__.'/sandbox_signature.b64')) {
    [, $private] = ensureKeys();
    $pkey = openssl_pkey_get_private($private);
    $details = openssl_pkey_get_details($pkey);
    $signature = base64_decode(file_get_contents(__DIR__.'/sandbox_signature.b64'), true);
    $verified = openssl_verify($unsigned, $signature, $details['key'], OPENSSL_ALGO_SHA256) === 1;
}
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head><meta charset="utf-8"><title>التوقيع التجريبي</title></head>
<body>
<h2>صفحة التوقيع والتحقق</h2>
<p>RSA-2048 / SHA-256 تجريبي فقط. لا يمثل توقيعًا مصرفيًا.</p>

<form method="post">
  <button name="sign" value="1">توقيع</button>
  <button name="verify" value="1">تحقق</button>
</form>

<?php if ($message): ?><p><?=htmlspecialchars($message)?></p><?php endif; ?>
<?php if ($verified !== null): ?><p>التحقق: <strong><?= $verified ? 'صحيح' : 'فشل' ?></strong></p><?php endif; ?>

<h3>Unsigned bytes / exact text</h3>
<pre><?=htmlspecialchars($unsigned)?></pre>

<?php if ($signature): ?>
<h3>Base64</h3>
<textarea rows="8" cols="110"><?=htmlspecialchars($signature)?></textarea>
<?php endif; ?>

<p><a href="compare.php">صفحة المقارنة</a> | <a href="index.php">البداية</a></p>
</body>
</html>
