<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$counterFile = __DIR__ . '/company_counter.txt';
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, '1');
}
$currentCount = (int)file_get_contents($counterFile);
$generatedCompanyCode = '0007' . str_pad($currentCount, 4, '0', STR_PAD_LEFT);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>توليد ملف الأجور - مدد</title>
    <style>
        body {
            background-color: #f7f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }
        .app-container {
            background-color: #ffffff;
            width: 100%;
            max-width: 480px;
            padding: 35px 25px;
            border-radius: 24px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.05);
            box-sizing: border-box;
        }
        .logout-link {
            text-align: left;
            margin-bottom: 10px;
        }
        .logout-link a {
            color: #e03131;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
        }
        h2 {
            text-align: center;
            color: #555;
            font-size: 18px;
            margin: 0 0 30px;
            font-weight: 500;
        }
        .input-group { margin-bottom: 20px; }
        label {
            display: block;
            margin-bottom: 7px;
            color: #2d2d2d;
            font-size: 14px;
            font-weight: 600;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 13px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            box-sizing: border-box;
            outline: none;
            background: #fff;
            color: #333;
            transition: border-color 0.2s;
        }
        input:focus, textarea:focus { border-color: #3b5bdb; }
        textarea {
            height: 150px;
            resize: vertical;
            direction: ltr;
            text-align: left;
            font-family: monospace;
        }
        small { display: block; margin-top: 4px; color: #888; font-size: 12px; }
        .buttons-row {
            display: flex;
            gap: 12px;
            margin-top: 28px;
        }
        button {
            flex: 1;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s, opacity 0.2s;
        }
        button:active { opacity: 0.85; }
        .btn-generate { background-color: #3b5bdb; color: white; }
        .btn-generate:hover { background-color: #2b49c4; }
        .btn-generate:disabled { background-color: #9baee8; cursor: not-allowed; }
        .btn-delete { background-color: #e0e0e0; color: #333; }
        .btn-delete:hover { background-color: #d2d2d2; }
        #statusMsg {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
            font-weight: 600;
            min-height: 20px;
            color: #3b5bdb;
        }
    </style>
</head>
<body>
<div class="app-container">
    <div class="logout-link">
        <a href="?logout=true">تسجيل الخروج</a>
    </div>
    <h2>توليد ملف الأجور - مدد</h2>

    <input type="hidden" id="companyIban" value="SA1580000305608016256457">

    <div class="input-group">
        <label>كود الشركة</label>
        <input type="text" id="companyCode" value="<?php echo htmlspecialchars($generatedCompanyCode); ?>">
    </div>
    <div class="input-group">
        <label>الرقم الموحد</label>
        <input type="text" id="unifiedNumber" placeholder="مثال: 12-1971485">
    </div>
    <div class="input-group">
        <label>راتب السعودي</label>
        <input type="number" id="saudiSalary" step="0.01" placeholder="0.00">
    </div>
    <div class="input-group">
        <label>راتب المقيم</label>
        <input type="number" id="residentSalary" step="0.01" placeholder="0.00">
    </div>
    <div class="input-group">
        <label>البدل (يُضاف لكل موظف)</label>
        <input type="number" id="allowance" step="0.01" value="0">
        <small>يُضاف إلى الراتب الأساسي لحساب الإجمالي</small>
    </div>
    <div class="input-group">
        <label>كود الموظف (اختياري)</label>
        <input type="text" id="employeeCodePrefix" placeholder="اتركه فارغاً لاستخدام --">
        <small>فارغ = "--" ، وإلا: prefix + 0001، 0002...</small>
    </div>
    <div class="input-group">
        <label>أرقام الهويات (سطر لكل رقم)</label>
        <textarea id="idList" placeholder="أدخل أرقام الهويات..."></textarea>
    </div>

    <div class="buttons-row">
        <button class="btn-generate" id="btnGenerate" onclick="generateAndSign()">توليد وتوقيع</button>
        <button class="btn-delete" onclick="clearFields()">مسح</button>
    </div>
    <div id="statusMsg"></div>
</div>

<script>
function clearFields() {
    document.getElementById('unifiedNumber').value = '';
    document.getElementById('saudiSalary').value = '';
    document.getElementById('residentSalary').value = '';
    document.getElementById('allowance').value = '0';
    document.getElementById('idList').value = '';
    document.getElementById('employeeCodePrefix').value = '';
    document.getElementById('statusMsg').textContent = '';
}

function setStatus(msg, color) {
    const el = document.getElementById('statusMsg');
    el.textContent = msg;
    el.style.color = color || '#3b5bdb';
}

function formatAmount16(amount) {
    return parseFloat(amount).toFixed(2).replace('.', ',').padStart(16, '0');
}

function formatAmount13(amount) {
    return parseFloat(amount).toFixed(2).replace('.', ',').padStart(13, '0');
}

async function generateIban(id, unifiedNumber, companyIban) {
    const cleanIban = companyIban.trim().replace(/\s+/g, '');
    const middlePart = cleanIban.substring(4, 20);
    const source = unifiedNumber.trim() + "|" + id.trim();
    const data = new TextEncoder().encode(source);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const digits = hashArray.map(x => x % 10).join('');
    return "SA" + digits.substring(0, 2) + middlePart + digits.substring(2, 6);
}

async function generateAndSign() {
    const unifiedNumber = document.getElementById('unifiedNumber').value.trim();
    const companyCode   = document.getElementById('companyCode').value.trim();
    const companyIban   = document.getElementById('companyIban').value.trim();
    const allowance     = parseFloat(document.getElementById('allowance').value) || 0;
    const saudiBase     = parseFloat(document.getElementById('saudiSalary').value) || 0;
    const residentBase  = parseFloat(document.getElementById('residentSalary').value) || 0;
    const idListRaw     = document.getElementById('idList').value;
    const codePrefix    = document.getElementById('employeeCodePrefix').value.trim();

    const ids = idListRaw.split(/\r?\n/).map(id => id.trim()).filter(id => id.length > 0);

    if (!unifiedNumber || !companyCode) {
        alert('الرجاء إدخال الرقم الموحد وكود الشركة.');
        return;
    }
    if (ids.length === 0) {
        alert('لم يتم إدخال أي أرقام هويات!');
        return;
    }

    document.getElementById('btnGenerate').disabled = true;
    setStatus('⏳ جارٍ توليد الملف...', '#3b5bdb');

    // ─── التاريخ: الأمس ───
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const dateStr = yesterday.getFullYear() +
        String(yesterday.getMonth() + 1).padStart(2, '0') +
        String(yesterday.getDate()).padStart(2, '0');
    const shortDate = dateStr.slice(2);

    // ─── H08 FileRef ───
    let fileRefInput = unifiedNumber + "  01-2";
    if (unifiedNumber === "12-4043297") fileRefInput = "12-4043297  01-2";
    else if (unifiedNumber === "09-176612") fileRefInput = "4180534 176612 4";
    const fileRefPad = fileRefInput.padEnd(16, ' ');

    const headerCompanyCode  = companyCode.padEnd(10, ' ');
    const headerUnifiedNum   = unifiedNumber.padEnd(18, ' ');

    // ─── أرقام عشوائية ───
    const startCentralRef = 1086237612 + Math.floor(Math.random() * 100);
    const baseTransRef    = 5000000000 + Math.floor(Math.random() * 999999999);

    let totalAmount  = 0;
    let recordsText  = "";

    for (let i = 0; i < ids.length; i++) {
        const id         = ids[i];
        const isSaudi    = id.startsWith('1');
        const baseSalary = isSaudi ? saudiBase : residentBase;
        const totalSalary = baseSalary + allowance;
        totalAmount += totalSalary;

        const empCode    = codePrefix === '' ? '--' : codePrefix + String(i + 1).padStart(4, '0');
        const iban       = await generateIban(id, unifiedNumber, companyIban);
        const centralRef = startCentralRef + i;
        const transRef   = shortDate + String(baseTransRef + i);
        const paddedId   = id.padStart(10, '0');

        const formatted16       = formatAmount16(totalSalary);
        const formatted13Basic  = formatAmount13(baseSalary);
        const formatted13Allow  = formatAmount13(allowance);   // F09
        const zeroField         = '0000000000,00';             // F08, F10

        const ibanPad  = iban.padEnd(34, ' ');
        const codePad  = empCode.padEnd(140, ' ');
        const rjhiPad  = 'RJHI'.padEnd(140, ' ');
        const refPad   = ('Centralization Ref:' + centralRef).padEnd(140, ' ');
        const blank    = '      ';

        // 14 حقل مفصولة بـ tab، نهاية كل سطر \r\n
        recordsText += `${formatted16}\t${ibanPad}\t${codePad}\t${rjhiPad}\t${refPad}\t${blank}\t${formatted13Basic}\t${zeroField}\t${formatted13Allow}\t${zeroField}\t${paddedId}\t${transRef}\tSuccess \t${dateStr}\r\n`;
    }

    // ─── السطر الأول (Header) ───
    const headerTotal = formatAmount16(totalAmount);
    const header = `RJHI\t${headerCompanyCode}\t${companyIban}\tSAR\t${dateStr}\t${headerTotal}\t${dateStr}\t${fileRefPad}\tP000  \t${headerUnifiedNum}\r\n`;

    const fileBody = header + recordsText;

    // ─── التوقيع عبر sign.php ───
    setStatus('⏳ جارٍ التوقيع...', '#3b5bdb');
    try {
        // تحويل fileBody إلى Base64 بشكل يدعم UTF-8
        const encodedB64 = btoa(unescape(encodeURIComponent(fileBody)));

        const response = await fetch("sign.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ b64content: encodedB64 })
        });

        if (!response.ok) throw new Error("sign.php أرجع خطأ HTTP " + response.status);

        const signature = await response.text();
        if (!signature || signature === 'NO_CONTENT') throw new Error("لم يُرجع sign.php توقيعاً");

        // ─── تجميع الملف النهائي: fileBody + "-\r\n" + signature ───
        const finalContent = fileBody + "-\r\n" + signature.trim();

        // ─── تحميل الملف ───
        const blob = new Blob([finalContent], { type: 'text/plain;charset=utf-8' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href     = url;
        a.download = `${companyCode}_W_${dateStr}.txt`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 0);

        // ─── تحديث عداد الشركة ───
        fetch('increment_counter.php')
            .then(r => r.text())
            .then(newCode => {
                if (newCode && newCode.length >= 6)
                    document.getElementById('companyCode').value = newCode;
            })
            .catch(() => {});

        setStatus('✅ تم توليد الملف وتوقيعه بنجاح!', '#059669');

    } catch (err) {
        setStatus('❌ خطأ في التوقيع: ' + err.message, '#e03131');
        console.error(err);
    } finally {
        document.getElementById('btnGenerate').disabled = false;
    }
}
</script>
</body>
</html>
