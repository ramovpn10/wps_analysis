# WPS Payroll Generator — Vercel / Next.js

هذا المشروع يعيد بناء مولّد ملفات الأجور على Next.js 16 + TypeScript، مع خادم Node.js داخل Route Handlers في Vercel.

## المرجع
- ملفات TXT الحديثة المقبولة هي المرجع النهائي لتنسيق الملف: Header 122، Detail 583، LF، separator، وRSA/Base64 signature format.
- الموقع القديم استُخدم فقط كمرجع خوارزمي لبعض المدخلات (مثل نمط توليد IBAN القديم) وليس كمرجع لتنسيق الملف الحديث.

## أهم نقطة قبل الإنتاج
التوقيع في الملفات الحديثة التي فحصناها لا يمكن إثبات مفتاحه من عينات TXT وحدها. لذلك التطبيق **لا يختلق توقيعًا**. يجب وضع المفتاح الخاص المعتمد حاليًا في `SIGNING_PRIVATE_KEY` على Vercel. التطبيق يستخدم RSA-SHA256 ويوقع الـbody النهائي قبل الفاصل، ثم يضيف `-\n` ثم Base64 بدون سطر إضافي بعده.

## التشغيل
```bash
npm install
npm run dev
```
ثم افتح `http://localhost:3000`.

## Vercel
1. ارفع المشروع إلى GitHub.
2. استورد المشروع في Vercel.
3. أضف `SIGNING_PRIVATE_KEY` كـSensitive Environment Variable.
4. إن رغبت بقاعدة بيانات دائمة، أضف `DATABASE_URL` من Neon.
5. Deploy.

## قاعدة البيانات
بدون `DATABASE_URL` يعمل الموقع ببيانات مرجعية مدمجة (Read-only seed) كي يكون جاهزًا للتجربة.
مع `DATABASE_URL` يستخدم Postgres لتخزين الموظفين/IBANات التي تضيفها من الواجهة.

## ملاحظة سلامة البيانات
الهويات يجب أن تكون بيانات حقيقية صادرة من الجهة النظامية. التطبيق لا يخترع هوية بشرية عند تركها فارغة؛ بل يوقف التوليد ويطلب إدخالها، حتى لا ينتج ملف أجور غير صالح.

### توليد IBAN
يوجد زر توليد IBAN في الواجهة باستخدام خوارزمية الموقع القديم المرفوع. هذه الخوارزمية وُضعت كمرجع فقط، لأن ملفات TXT الحديثة لا تحتوي على الهويات التي تسمح بإثباتها حرفيًا. للاعتماد التشغيلي، استخدم IBAN مرجعيًا/يدويًا عندما يكون معروفًا.

## Exact-acceptance caveat
The new accepted TXT signatures were tested against the public key from the old supplied PHP site and did not verify. This means the new accepted environment is using a different signing key (or a different signing protocol). The project therefore refuses to invent a signature. Set the current authorized `SIGNING_PRIVATE_KEY` before expecting an exact accepted file.

## Signing compatibility with the legacy site

The signer intentionally mirrors the legacy PHP `sign.php`:

- algorithm: RSA-SHA256
- RSA padding: PKCS#1 v1.5 (`openssl_sign(..., OPENSSL_ALGO_SHA256)` equivalent)
- input: the exact UTF-8 bytes of the unsigned file body
- output: Base64-encoded 256-byte signature (344 Base64 characters)

Use the **same `private.pem` key currently used by the legacy system** by placing its exact PEM contents in the Vercel server environment variable `SIGNING_PRIVATE_KEY`. Do not commit the PEM file to the repository or client-side code.

The new accepted files are LF-only, so the signer preserves LF line endings in the file body and appends `-\n` before the Base64 signature. The legacy PHP page used CRLF when appending, but the current accepted reference files are the authority for line-ending format.


## مفاتيح التوقيع المرفوعة
تم تجهيز المشروع محليًا بملفي `secrets/private.pem` و`secrets/public.pem` اللذين رفعتَهما.
يفضل على Vercel استخدام `SIGNING_PRIVATE_KEY` بدل رفع المفتاح إلى Git، لكن الكود يحتوي على fallback محلي إلى `secrets/private.pem`.
تم التحقق محليًا أن المفتاحين زوج واحد، وأن التوقيع RSA-SHA256 الناتج = 256 بايت و344 حرف Base64.


### Vercel Environment Variables
```text
SIGNING_PRIVATE_KEY=<contents of private.pem>
SIGNING_PUBLIC_KEY=<contents of public.pem>
DATABASE_URL=<Neon connection string>
```
The deployed service prefers these environment variables. The bundled `secrets/` files are provided only as a local-ready fallback and should not be committed to a public repository.
